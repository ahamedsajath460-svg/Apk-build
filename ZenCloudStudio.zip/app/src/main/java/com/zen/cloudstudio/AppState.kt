package com.zen.cloudstudio

/** True while the app is on screen (the background build watcher then leaves the work to the page). */
object AppState {
    @Volatile var visible = false
}
