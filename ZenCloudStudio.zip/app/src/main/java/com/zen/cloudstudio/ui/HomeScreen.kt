package com.zen.cloudstudio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable
fun HomeScreen(onCreate: () -> Unit, onBuilds: () -> Unit, onSettings: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    var usage by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(st.setupOk) { if (st.setupOk) e.run("usage", key = "usage") { usage = it as? JSONObject } }

    LazyColumn(contentPadding = pagePadding(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(BrandBrush).padding(24.dp)) {
                Row(
                    Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.2f)).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Zen Cloud Studio", color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
                Spacer(Modifier.height(16.dp))
                Text("Describe it.\nWe build it.", color = Color.White, style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "AI writes your Android app. GitHub builds it in the cloud. Nothing compiles on your phone.",
                    color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onCreate, shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Violet),
                    modifier = Modifier.height(50.dp)
                ) {
                    Icon(Icons.Rounded.RocketLaunch, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Create new app", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
        if (!st.setupOk) item { SetupCard(st, onSettings) }
        item {
            val u = usage
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ConnChip(Icons.Rounded.Link, "GitHub", if (st.token) "Connected" else "Not set", if (st.token) Ok else Warn, Modifier.weight(1f))
                ConnChip(Icons.Rounded.Cloud, "Cloud", if (st.running > 0) "${st.running} running" else "Idle", Blue, Modifier.weight(1f))
                ConnChip(Icons.Rounded.Storage, "Storage", if (u != null) bytes(u.optLong("storageBytes")) else "—", Violet, Modifier.weight(1f))
            }
        }
        item { SectionTitle("Overview") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile("${st.projects.size}", "Active projects", Icons.Rounded.FolderOpen, Violet, Modifier.weight(1f))
                    StatTile("${st.builds.size}", "Total builds", Icons.Rounded.Construction, Blue, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile("${st.ok}", "Successful", Icons.Rounded.CheckCircle, Ok, Modifier.weight(1f))
                    StatTile("${st.bad}", "Failed", Icons.Rounded.Error, Bad, Modifier.weight(1f))
                }
            }
        }
        item { SectionTitle("Recent builds", if (st.builds.isNotEmpty()) "See all" else null, onBuilds) }
        if (st.builds.isEmpty()) item { Text("No builds yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(st.builds.take(4)) { BuildRow(it, onBuilds) }
    }
}

@Composable
private fun ConnChip(icon: ImageVector, title: String, value: String, tint: Color, modifier: Modifier) {
    AppCard(modifier) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}
