package com.zen.cloudstudio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.zen.cloudstudio.obj

@Composable
fun ProjectsScreen(onOpen: (Project) -> Unit, onBuild: (Project) -> Unit, onNew: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    var delete by remember { mutableStateOf<Project?>(null) }
    var remote by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        val base = pagePadding()
        LazyColumn(
            contentPadding = PaddingValues(20.dp, base.calculateTopPadding(), 20.dp, 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ScreenTitle("My Projects", "${st.projects.size} apps on this phone") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { e.pickImport(null) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.UploadFile, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Import")
                    }
                    OutlinedButton(onClick = { remote = true }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.CloudDownload, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("From GitHub")
                    }
                }
            }
            if (st.projects.isEmpty()) item { Text("No projects yet. Create one with the AI or import a ZIP.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(st.projects) { p ->
                var menu by remember { mutableStateOf(false) }
                AppCard(onClick = { onOpen(p) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Rounded.Android, Ok, 48)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text(p.pkg.ifBlank { p.slug }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text(if ("pull${p.id}" in busy) "Pulling…" else "Pull from GitHub") }, leadingIcon = { Icon(Icons.Rounded.CloudDownload, null) },
                                    onClick = { menu = false; e.run("projectPull", obj("pid" to p.id), key = "pull${p.id}") { e.messages.tryEmit("Pulled from GitHub") } }
                                )
                                DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Bad) }, onClick = { menu = false; delete = p })
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Updated ${ago(p.updated)}" + if (p.dirty) " · not pushed to GitHub yet" else "",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(onClick = { onOpen(p) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Code, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Open")
                        }
                        Button(onClick = { onBuild(p) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Build")
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = onNew, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            icon = { Icon(Icons.Rounded.Add, null) }, text = { Text("New app") },
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary
        )
    }

    delete?.let { p ->
        ConfirmDialog(
            "Delete project?", "Deletes \"${p.name}\" and its build records from this phone. Files on GitHub (branch ${p.branch}) stay until you delete the branch there.",
            "Delete", danger = true, onYes = { e.run("projectDelete", obj("pid" to p.id)) }, onDismiss = { delete = null }
        )
    }
    if (remote) {
        var slug by remember { mutableStateOf("") }
        var branch by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { remote = false }, title = { Text("Add from GitHub") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(slug, { slug = it }, singleLine = true, label = { Text("Folder under cloud-projects/") })
                    OutlinedTextField(branch, { branch = it }, singleLine = true, label = { Text("Branch (optional)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    remote = false
                    e.run("projectAddRemote", obj("slug" to slug, "branch" to branch), key = "remote") { r ->
                        (r as? org.json.JSONObject)?.optString("pid")?.let { e.selectedPid.value = it }
                        e.messages.tryEmit("Project added from GitHub")
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { remote = false }) { Text("Cancel") } }
        )
    }
}
