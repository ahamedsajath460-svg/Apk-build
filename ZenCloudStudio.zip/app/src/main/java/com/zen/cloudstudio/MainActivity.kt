package com.zen.cloudstudio

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = ArrayList<Uri>()
        if (result.resultCode == RESULT_OK) {
            val clip = result.data?.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
            } else {
                result.data?.data?.let { uris.add(it) }
            }
        }
        fileCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        fileCallback = null
        if (uris.isEmpty()) web.evaluateJavascript("window.__csPickCancel && window.__csPickCancel()", null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false

        val bridge = CloudBridge(this) { web }
        saveDefaultToken(bridge)
        web.addJavascriptInterface(bridge, "A2ZCloud")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (request.url.host != HOST) return null
                val name = request.url.lastPathSegment ?: ""
                if (name !in PAGES) return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                val type = if (name.endsWith(".js")) "text/javascript" else "text/html"
                return WebResourceResponse(type, "UTF-8", assets.open(name))
            }

            // Only the app's own page stays inside the app; web links open in the browser.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == HOST) return false
                if (url.scheme == "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (_: ActivityNotFoundException) { }
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*\u002F*")
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                return try {
                    filePicker.launch(Intent.createChooser(intent, "Choose files"))
                    true
                } catch (_: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.appBack ? window.appBack() : false") { handled ->
                    // Keep running in the background so that builds and AI jobs are not lost.
                    if (handled != "true") moveTaskToBack(true)
                }
            }
        })

        setContentView(web)
        web.loadUrl("https://$HOST/index.html")
        askPermissions()
    }

    /** Stores the token from DefaultToken.kt (encrypted) once. A token saved or removed in the app is not overwritten. */
    private fun saveDefaultToken(bridge: CloudBridge) {
        val token = DefaultToken.GITHUB
        if (token.isEmpty()) return
        val prefs = getSharedPreferences("default_token", Context.MODE_PRIVATE)
        val mark = CloudCore.hex(java.security.MessageDigest.getInstance("SHA-256").digest(token.toByteArray()))
        if (prefs.getString("saved", "") == mark) return
        if (bridge.setToken("local", token) == "ok") prefs.edit().putString("saved", mark).apply()
    }

    private fun askPermissions() {
        val wanted = ArrayList<String>()
        if (DownloadsSaver.needsPermission(this)) wanted.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (wanted.isNotEmpty()) ActivityCompat.requestPermissions(this, wanted.toTypedArray(), 1)
    }

    override fun onStart() {
        super.onStart()
        AppState.visible = true
    }

    override fun onStop() {
        AppState.visible = false
        super.onStop()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val HOST = "zencloud.local"
        private val PAGES = setOf(
            "index.html", "ai-config.js", "ai.js", "cloudstudio-core.js", "cloudstudio-gen.js", "cloudstudio-import.js", "cloudstudio-setup.js", "cloudstudio-ui.js"
        )
    }
}
