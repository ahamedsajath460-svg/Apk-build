package com.zen.cloudstudio.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Violet = Color(0xFF6D4CFF)
val Blue = Color(0xFF3B82F6)
val Cyan = Color(0xFF22D3EE)
val Ok = Color(0xFF22A06B)
val Bad = Color(0xFFE5484D)
val Warn = Color(0xFFF5A524)
val BrandBrush = Brush.linearGradient(listOf(Color(0xFF6D4CFF), Color(0xFF4F6BFF), Color(0xFF22B8E8)))

private val Light = lightColorScheme(
    primary = Violet, onPrimary = Color.White,
    primaryContainer = Color(0xFFE9E3FF), onPrimaryContainer = Color(0xFF1C0066),
    secondary = Color(0xFF0E8FB0), tertiary = Blue,
    background = Color(0xFFF6F5FB), onBackground = Color(0xFF15131F),
    surface = Color.White, onSurface = Color(0xFF15131F),
    surfaceVariant = Color(0xFFEEEBF8), onSurfaceVariant = Color(0xFF5C5973),
    outline = Color(0xFFDCD9EA), error = Bad
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB9A9FF), onPrimary = Color(0xFF260C9A),
    primaryContainer = Color(0xFF38298A), onPrimaryContainer = Color(0xFFE9E3FF),
    secondary = Color(0xFF5ED3F0), tertiary = Color(0xFF8AB4FF),
    background = Color(0xFF0D0C13), onBackground = Color(0xFFEDEBF7),
    surface = Color(0xFF16141F), onSurface = Color(0xFFEDEBF7),
    surfaceVariant = Color(0xFF221F2F), onSurfaceVariant = Color(0xFFB3AFC7),
    outline = Color(0xFF332F45), error = Color(0xFFFF7B80)
)

private val Type = Typography(
    headlineLarge = TextStyle(fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium)
)

private val Shapes = Shapes(
    small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp), extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ZenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = Type, shapes = Shapes, content = content
    )
}
