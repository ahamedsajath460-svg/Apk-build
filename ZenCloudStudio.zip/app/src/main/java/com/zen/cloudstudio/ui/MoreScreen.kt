package com.zen.cloudstudio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

private data class MoreItem(val route: String, val title: String, val sub: String, val icon: ImageVector, val tint: androidx.compose.ui.graphics.Color)

@Composable
fun MoreScreen(go: (String) -> Unit) {
    val entries = remember {
        listOf(
            MoreItem("paste", "Paste Code", "Paste code and get an APK", Icons.Rounded.ContentPaste, Blue),
            MoreItem("workspace", "Code Workspace", "Edit files, AI edit, push to GitHub", Icons.Rounded.Code, Violet),
            MoreItem("apks", "APK Manager", "Download, install and share APKs", Icons.Rounded.Android, Ok),
            MoreItem("preview", "Live Preview", "Preview screens before building", Icons.Rounded.Visibility, Blue),
            MoreItem("device", "Virtual Device", "Run a real emulator test in the cloud", Icons.Rounded.Smartphone, Warn),
            MoreItem("sdk", "Android SDK", "Choose platforms and build tools", Icons.Rounded.Memory, Cyan),
            MoreItem("settings", "Cloud Settings", "GitHub token, repository, limits", Icons.Rounded.Settings, Violet)
        )
    }
    LazyColumn(contentPadding = pagePadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle("More", "Tools and settings") }
        items(entries.size) { i ->
            val m = entries[i]
            AppCard(onClick = { go(m.route) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(m.icon, m.tint)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.title, style = MaterialTheme.typography.titleMedium)
                        Text(m.sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.AutoMirrored.Rounded.ArrowForwardIos, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
