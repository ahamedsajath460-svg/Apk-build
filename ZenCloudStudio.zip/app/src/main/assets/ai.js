/* ask(system, text) with automatic fallback over all providers, models and keys in ai-config.js. */
(function (W) {
  'use strict';
  var blocked = {};   // "provider|key|model" or "provider|key" -> time until which it is skipped
  var NEVER = 8.64e15;

  function post(url, headers, body, ms) {
    var stop = new AbortController(), t = setTimeout(function () { stop.abort(); }, ms);
    headers['Content-Type'] = 'application/json';
    return fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(body), signal: stop.signal })
      .then(function (r) { return r.json().catch(function () { return null; }).then(function (j) { return { ok: r.ok, status: r.status, j: j }; }); })
      .finally(function () { clearTimeout(t); });
  }

  function call(p, model, key, sys, text) {
    if (p.type === 'gemini') {
      return post(p.url + model + ':generateContent', { 'x-goog-api-key': key },
        { systemInstruction: { parts: [{ text: sys }] }, contents: [{ role: 'user', parts: [{ text: text }] }] }, 150000)
        .then(function (r) {
          var c = r.j && r.j.candidates && r.j.candidates[0];
          var out = ((c && c.content && c.content.parts) || []).filter(function (x) { return !x.thought; }).map(function (x) { return x.text || ''; }).join('');
          return { r: r, text: out, trunc: !!c && c.finishReason === 'MAX_TOKENS' };
        });
    }
    return post(p.url, { 'Authorization': 'Bearer ' + key },
      { model: model, messages: [{ role: 'system', content: sys }, { role: 'user', content: text }] }, 150000)
      .then(function (r) {
        var c = (r.j && r.j.choices && r.j.choices[0]) || {};
        return { r: r, text: (c.message && c.message.content) || '', trunc: c.finish_reason === 'length' };
      });
  }

  W.ask = function (sys, text) {
    var list = [];
    (W.AI_CONFIG.providers || []).forEach(function (p) {
      p.models.forEach(function (m) { p.keys.forEach(function (k, i) { if (k) list.push({ p: p, m: m, k: k, id: p.name + '|' + i }); }); });
    });
    var i = 0, errors = [], cut = null;
    function next() {
      if (i >= list.length) {
        if (cut) return Promise.resolve(cut);
        return Promise.reject(new Error('No AI service answered. ' + (errors.slice(-4).join('; ') || 'All keys are resting after errors. Wait a minute or check the keys in ai-config.js.')));
      }
      var x = list[i++], now = Date.now(), one = x.id + '|' + x.m;
      if (blocked[x.id] > now || blocked[one] > now) return next();
      return call(x.p, x.m, x.k, sys, text).then(function (a) {
        var s = a.r.status, bad = !a.r.ok || !a.r.j || a.r.j.error;
        if (!bad && a.text) {
          if (!a.trunc) return { text: a.text, trunc: false };
          cut = { text: a.text, trunc: true }; return next();
        }
        var msg = String((a.r.j && a.r.j.error && a.r.j.error.message) || '').split(x.k).join('***').slice(0, 120);
        errors.push(x.p.name + ' ' + x.m + ': ' + (bad ? s + ' ' + msg : 'empty reply'));
        if (s === 401 || /api.?key/i.test(msg)) blocked[x.id] = NEVER;             // bad key: skip all its models
        else if (s === 402 || s === 403 || s === 429) blocked[one] = now + 60000;  // limit or no credit for this model
        return next();
      }, function (e) {
        errors.push(x.p.name + ' ' + x.m + ': ' + (e.name === 'AbortError' ? 'timed out' : 'network error'));
        return next();
      });
    }
    return next();
  };

  /* Returns short web results as text, or '' if search is not available. Never fails. */
  W.webSearch = function (query) {
    var s = W.AI_CONFIG.search, keys = ((s && s.keys) || []).filter(Boolean), i = 0;
    function next() {
      if (i >= keys.length) return Promise.resolve('');
      return post(s.url, { 'Authorization': 'Bearer ' + keys[i++] }, { query: String(query).slice(0, 380), max_results: 3 }, 15000).then(function (r) {
        if (!r.ok || !r.j || !r.j.results) return next();
        return r.j.results.map(function (x) { return '- ' + x.title + ': ' + String(x.content || '').slice(0, 400); }).join('\n');
      }, next);
    }
    return next();
  };
})(window);
