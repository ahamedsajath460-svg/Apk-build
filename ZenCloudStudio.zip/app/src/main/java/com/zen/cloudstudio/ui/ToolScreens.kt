package com.zen.cloudstudio.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zen.cloudstudio.obj
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private val CodeBg = Color(0xFF14121C)
private val Token = Regex("//.*|\"[^\"]*\"|\\b(package|import|class|fun|val|var|override|return|if|else|private|object|true|false|null|plugins|android)\\b|\\b\\d+\\b|</?[A-Za-z]+")

private fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in Token.findAll(code)) {
        append(code.substring(last, m.range.first))
        val t = m.value
        val c = when {
            t.startsWith("//") -> Color(0xFF7F8CA3)
            t.startsWith("\"") -> Color(0xFF98D982)
            t.startsWith("<") -> Color(0xFFFF8A8F)
            t[0].isDigit() -> Color(0xFFFFB86B)
            else -> Color(0xFFC3A6FF)
        }
        withStyle(SpanStyle(color = c)) { append(t) }
        last = m.range.last + 1
    }
    append(code.substring(last))
}

private val Highlighter = VisualTransformation { t -> TransformedText(highlight(t.text), OffsetMapping.Identity) }

private class Act(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val onClick: () -> Unit)

private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else List(length()) { optString(it) }

/* ───────────── Code Workspace ───────────── */

@Composable
fun WorkspaceScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val p = currentProject(st)
    SubScreen(p?.name ?: "Code Workspace", onBack) { pad ->
        if (p == null) Box(Modifier.padding(pad).padding(20.dp)) { Text("No project yet. Create or import one first.") }
        else Editor(p, Modifier.padding(pad))
    }
}

@Composable
private fun Editor(p: Project, modifier: Modifier) {
    val e = LocalEngine.current
    val busy by e.busy.collectAsState()
    var files by remember(p.id) { mutableStateOf(mapOf<String, String>()) }
    var lint by remember(p.id) { mutableStateOf(listOf<String>()) }
    var cur by remember(p.id) { mutableStateOf("") }
    var version by remember(p.id) { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var field by remember { mutableStateOf("") }
    var aiResult by remember { mutableStateOf("") }
    var snaps by remember { mutableStateOf(listOf<Triple<String, Long, String>>()) }
    var rollbackId by remember { mutableStateOf("") }

    fun load(select: String? = null) {
        e.run("filesGet", obj("pid" to p.id), key = "files") { r ->
            val o = r as JSONObject
            val f = o.getJSONObject("files")
            files = f.keys().asSequence().associateWith { f.getString(it) }
            val l = o.optJSONArray("lint")
            lint = if (l == null) emptyList() else List(l.length()) { i -> l.getJSONObject(i).let { "${it.optString("path")}:${it.optInt("line")} ${it.optString("message")}" } }
            cur = select?.takeIf { files.containsKey(it) } ?: cur.takeIf { files.containsKey(it) } ?: files.keys.sorted().firstOrNull().orEmpty()
            version++
        }
    }
    LaunchedEffect(p.id) { load() }

    var text by remember(cur, version) { mutableStateOf(files[cur].orEmpty()) }
    LaunchedEffect(text) {
        if (cur.isNotEmpty() && text != files[cur]) {
            delay(700)
            e.run("fileSave", obj("pid" to p.id, "path" to cur, "content" to text), key = "save") { files = files + (cur to text) }
        }
    }
    fun saveNow(after: () -> Unit) {
        if (cur.isEmpty() || text == files[cur]) { after(); return }
        e.run("fileSave", obj("pid" to p.id, "path" to cur, "content" to text), key = "save") { files = files + (cur to text); after() }
    }

    Column(modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files.keys.sorted()) { f ->
                FilterChip(selected = cur == f, onClick = { saveNow { cur = f } }, label = { Text(f.substringAfterLast('/')) })
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val acts = listOf(
                Act("New", Icons.Rounded.NoteAdd) { field = "app/src/main/java/"; dialog = "new" },
                Act("Rename", Icons.Rounded.DriveFileRenameOutline) { field = cur; dialog = "rename" },
                Act("Delete", Icons.Rounded.Delete) { dialog = "delete" },
                Act("AI edit", Icons.Rounded.AutoAwesome) { field = ""; dialog = "ai" },
                Act("History", Icons.Rounded.History) {
                    e.run("snaps", obj("pid" to p.id), key = "snaps") { r ->
                        val a = r as JSONArray
                        snaps = List(a.length()) { i -> a.getJSONObject(i).let { Triple(it.optString("id"), it.optLong("t"), it.optString("label")) } }
                        dialog = "history"
                    }
                },
                Act("Add files", Icons.Rounded.UploadFile) { e.pickImport(p.id) },
                Act(if ("push" in busy) "Pushing…" else "Push", Icons.Rounded.CloudUpload) {
                    saveNow { e.run("push", obj("pid" to p.id), key = "push") { r -> e.messages.tryEmit("Pushed to GitHub (${(r as? JSONObject)?.optInt("changed") ?: 0} file(s) changed)") } }
                }
            )
            items(acts) { a -> AssistChip(onClick = a.onClick, label = { Text(a.label) }, leadingIcon = { Icon(a.icon, null, Modifier.size(18.dp)) }) }
        }
        val mine = lint.filter { it.startsWith("$cur:") }
        if (mine.isNotEmpty()) Text(
            "${mine.size} problem(s): ${mine.first().substringAfter(' ')}", color = Warn, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)
        )
        Box(
            Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(CodeBg).verticalScroll(rememberScrollState()).padding(14.dp)
        ) {
            if (cur.isEmpty()) Text("No files.", color = Color(0xFF9A96B0))
            else BasicTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Color(0xFFE7E4F5), fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, lineHeight = 19.sp),
                cursorBrush = SolidColor(Cyan), visualTransformation = Highlighter
            )
        }
    }

    when (dialog) {
        "new", "rename" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text(if (dialog == "new") "New file" else "Rename file") },
            text = { OutlinedTextField(field, { field = it }, singleLine = true, label = { Text("Path in the project") }) },
            confirmButton = {
                TextButton(onClick = {
                    val path = field.trim(); val old = cur; val renaming = dialog == "rename"; dialog = ""
                    if (path.isEmpty()) return@TextButton
                    val body = if (renaming) text else ""
                    e.run("fileSave", obj("pid" to p.id, "path" to path, "content" to body), key = "save") {
                        if (renaming && old != path) e.run("fileSave", obj("pid" to p.id, "path" to old, "content" to null), key = "save") { load(path) } else load(path)
                    }
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
        )
        "delete" -> ConfirmDialog("Delete file?", "$cur will be removed. A restore point is saved first (History).", "Delete", danger = true,
            onYes = { e.run("fileDeleteSafe", obj("pid" to p.id, "path" to cur), key = "save") { cur = ""; load() } }, onDismiss = { dialog = "" })
        "ai" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("AI edit: ${cur.substringAfterLast('/')}") },
            text = { OutlinedTextField(field, { field = it }, minLines = 3, label = { Text("What should change?") }) },
            confirmButton = {
                TextButton(enabled = field.isNotBlank(), onClick = {
                    val ins = field; dialog = ""
                    saveNow {
                        e.run("aiEdit", obj("pid" to p.id, "path" to cur, "instruction" to ins), key = "aiedit") { r -> aiResult = (r as JSONObject).optString("content"); dialog = "aiReview" }
                    }
                }) { Text("Ask AI") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
        )
        "aiReview" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Apply this change?") },
            text = {
                Text(aiResult.take(2500), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
            },
            confirmButton = {
                TextButton(onClick = {
                    dialog = ""; val path = cur; val body = aiResult
                    e.run("snapBefore", obj("pid" to p.id, "label" to "Before AI edit of $path"), key = "save") {
                        e.run("fileSave", obj("pid" to p.id, "path" to path, "content" to body), key = "save") { files = files + (path to body); version++ }
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Discard") } }
        )
        "history" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Restore points") },
            text = {
                if (snaps.isEmpty()) Text("No restore points yet.")
                else LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(snaps) { s ->
                        TextButton(onClick = { rollbackId = s.first; dialog = "rollback" }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) { Text(s.third, style = MaterialTheme.typography.titleMedium); Text(ago(s.second), style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close") } }
        )
        "rollback" -> ConfirmDialog("Restore this version?", "Your current files are saved as a restore point first.", "Restore",
            onYes = { e.run("rollback", obj("pid" to p.id, "id" to rollbackId), key = "save") { load() } }, onDismiss = { dialog = "" })
    }
}

/* ───────────── APK Manager ───────────── */

@Composable
fun ApkScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    var del by remember { mutableStateOf<ApkItem?>(null) }
    SubScreen("APK Manager", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (st.artifacts.isEmpty()) item { Text("No APKs yet. Run a build first.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(st.artifacts) { a ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Rounded.Android, Ok)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${a.project} · ${a.kind}" + (if (a.size > 0) " · ${bytes(a.size)}" else "") + if (a.downloaded) " · saved on phone" else "",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val key = "dl${a.id}"
                        Button(onClick = { e.run("apkDownload", obj("id" to a.id), key = key) { e.messages.tryEmit("APK saved to your phone") } }, enabled = key !in busy, shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(if (key in busy) "Downloading…" else if (a.downloaded) "Download again" else "Download")
                        }
                        if (a.downloaded) OutlinedButton(onClick = { e.run("apkShare", obj("id" to a.id), key = "share") }, shape = RoundedCornerShape(12.dp)) { Icon(Icons.Rounded.Share, null, Modifier.size(18.dp)) }
                        OutlinedButton(onClick = { del = a }, shape = RoundedCornerShape(12.dp)) { Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp), tint = Bad) }
                    }
                }
            }
        }
    }
    del?.let { a ->
        ConfirmDialog("Delete APK?", "Removes ${a.name} from GitHub. The copy on your phone is not touched.", "Delete", danger = true,
            onYes = { e.run("apkRemove", obj("id" to a.id), key = "rm${a.id}") }, onDismiss = { del = null })
    }
}

/* ───────────── Android SDK ───────────── */

private val SdkOptions = listOf(
    "Android 13 platform" to "platforms;android-33", "Android 15 platform" to "platforms;android-35", "Build tools 35.0.0" to "build-tools;35.0.0",
    "NDK 26.1 (native code, large)" to "ndk;26.1.10909125", "CMake 3.22.1" to "cmake;3.22.1"
)

@Composable
fun SdkScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val p = currentProject(st)
    SubScreen("Android SDK", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { AppCard { Text("compileSdk 34 and build-tools 34.0.0 are always installed. Add extras below; they are used by the next build of ${p?.name ?: "your project"}.", style = MaterialTheme.typography.bodyMedium) } }
            if (p != null) items(SdkOptions) { (label, id) ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Switch(checked = id in p.sdk, onCheckedChange = { on ->
                            val next = if (on) p.sdk + id else p.sdk - id
                            e.run("sdkSet", obj("pid" to p.id, "list" to JSONArray(next)), key = "sdk") { e.refresh() }
                        })
                    }
                }
            }
        }
    }
}

/* ───────────── Cloud Settings ───────────── */

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    val c = st.cfg
    var token by remember { mutableStateOf("") }
    var repo by remember(st.repo) { mutableStateOf(st.repo) }
    var aiKey by remember { mutableStateOf("") }
    var model by remember(st.aiModel) { mutableStateOf(st.aiModel) }
    var fast by remember(st.ready) { mutableStateOf(st.aiFast) }
    var par by remember(st.ready) { mutableFloatStateOf(st.aiPar.toFloat()) }
    var retries by remember(st.ready) { mutableFloatStateOf(c.optInt("retryLimit", 3).toFloat()) }
    var days by remember(st.ready) { mutableFloatStateOf(c.optInt("retentionDays", 7).toFloat()) }
    var active by remember(st.ready) { mutableFloatStateOf(c.optInt("maxActive", 1).toFloat()) }
    var gradle by remember(st.ready) { mutableStateOf(c.optString("gradleVersion", "8.7")) }
    var test by remember { mutableStateOf<JSONObject?>(null) }
    var removeToken by remember { mutableStateOf(false) }

    SubScreen("Cloud Settings", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { SectionTitle("GitHub") }
            item { Text(if (st.token) "A token is stored securely on this phone." else "No token saved yet.", color = if (st.token) Ok else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
            item {
                OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Personal access token") },
                    visualTransformation = PasswordVisualTransformation(), leadingIcon = { Icon(Icons.Rounded.Key, null) }, shape = RoundedCornerShape(16.dp))
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(enabled = token.isNotBlank() && "token" !in busy, onClick = {
                        e.run("setToken", obj("token" to token), key = "token") { r -> token = ""; e.messages.tryEmit("Connected as ${(r as? JSONObject)?.optString("login")}"); e.refresh() }
                    }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) { Text(if ("token" in busy) "Checking…" else "Save token") }
                    if (st.token) OutlinedButton(onClick = { removeToken = true }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) { Text("Remove", color = Bad) }
                }
            }
            item {
                OutlinedTextField(repo, { repo = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Repository (owner/name)") },
                    leadingIcon = { Icon(Icons.Rounded.Link, null) }, shape = RoundedCornerShape(16.dp))
            }
            item {
                SecondaryButton(if ("repo" in busy) "Testing…" else "Save and test connection", Icons.Rounded.Wifi) {
                    e.run("testRepo", obj("repo" to repo.trim()), key = "repo") { r -> test = r as? JSONObject; e.refresh() }
                }
            }
            test?.let { t ->
                item {
                    AppCard {
                        Text(t.optString("name"), style = MaterialTheme.typography.titleMedium)
                        Text("${if (t.optBoolean("priv")) "Private" else "Public"} · default branch ${t.optString("branch")}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        val w = t.optJSONArray("workflows")
                        if (w != null) for (i in 0 until w.length()) {
                            val o = w.getJSONObject(i)
                            Text((if (o.optBoolean("ok")) "✓ " else "✗ ") + o.optString("file"), color = if (o.optBoolean("ok")) Ok else Bad, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (w != null && (0 until w.length()).any { !w.getJSONObject(it).optBoolean("ok") })
                            Text("Missing workflow files must be added to the repository's default branch before builds can run.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item { SectionTitle("AI") }
            item { Text(if (st.aiKey) "An OpenRouter key is saved." else "No OpenRouter key saved yet.", color = if (st.aiKey) Ok else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
            item {
                OutlinedTextField(aiKey, { aiKey = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (st.aiKey) "New OpenRouter key (leave empty to keep)" else "OpenRouter key") },
                    visualTransformation = PasswordVisualTransformation(), leadingIcon = { Icon(Icons.Rounded.Key, null) }, shape = RoundedCornerShape(16.dp))
            }
            item { OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model") }, shape = RoundedCornerShape(16.dp)) }
            item {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Fast mode", style = MaterialTheme.typography.titleMedium)
                            Text("Uses the fastest provider of the model and retries busy servers.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = fast, onCheckedChange = { fast = it })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Files written at the same time: ${par.toInt()}", style = MaterialTheme.typography.titleMedium)
                    Slider(par, { par = it }, valueRange = 1f..4f, steps = 2)
                    Text("Higher is faster. Lower it if your model shows rate-limit errors.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                SecondaryButton("Save AI settings", Icons.Rounded.Check) {
                    // a saved key is not readable by the page UI, so an empty field keeps the stored key
                    e.run("saveAiKeep", obj("key" to aiKey, "model" to model.trim(), "fast" to fast, "par" to par.toInt()), key = "ai") { aiKey = ""; e.messages.tryEmit("AI settings saved"); e.refresh() }
                }
            }
            item { SectionTitle("Limits") }
            item {
                AppCard {
                    Text("Automatic fix attempts: ${retries.toInt()}", style = MaterialTheme.typography.titleMedium)
                    Slider(retries, { retries = it }, valueRange = 0f..6f, steps = 5)
                    Text("Builds running at once: ${active.toInt()}", style = MaterialTheme.typography.titleMedium)
                    Slider(active, { active = it }, valueRange = 1f..3f, steps = 1)
                    Text("Keep APKs on GitHub: ${days.toInt()} days", style = MaterialTheme.typography.titleMedium)
                    Slider(days, { days = it }, valueRange = 1f..30f)
                    OutlinedTextField(gradle, { gradle = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Gradle version") }, shape = RoundedCornerShape(16.dp))
                }
            }
            item {
                PrimaryButton("Save limits", Icons.Rounded.Check) {
                    e.run("saveCfg", obj("retryLimit" to retries.toInt(), "maxActive" to active.toInt(), "retentionDays" to days.toInt(), "gradleVersion" to gradle.trim()), key = "cfg") { e.messages.tryEmit("Saved"); e.refresh() }
                }
            }
        }
    }
    if (removeToken) ConfirmDialog("Remove token?", "The GitHub token is deleted from this phone. Builds stop until you save a new one.", "Remove", danger = true,
        onYes = { e.run("clearToken", key = "token") { e.refresh() } }, onDismiss = { removeToken = false })
}

/* ───────────── Live Preview ───────────── */

@Composable
fun PreviewScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val p = currentProject(st)
    var list by remember(p?.id) { mutableStateOf(listOf<String>()) }
    var sel by remember(p?.id) { mutableStateOf("") }
    var width by remember { mutableIntStateOf(0) }
    LaunchedEffect(p?.id) {
        if (p != null) e.run("previewList", obj("pid" to p.id), key = "plist") { r -> list = (r as JSONArray).strings(); sel = list.firstOrNull().orEmpty() }
    }
    SubScreen("Live Preview", onBack) { pad ->
        Column(Modifier.padding(pad).padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Preview a web page or an Android layout (XML) before you build.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (list.isEmpty()) Text("This project has no HTML file or layout XML to preview.")
            list.forEach { f -> FilterChip(selected = sel == f, onClick = { sel = f }, label = { Text(f) }) }
            Text("Width", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "Auto", 360 to "360", 412 to "412", 768 to "Tablet").forEach { (w, l) -> FilterChip(selected = width == w, onClick = { width = w }, label = { Text(l) }) }
            }
            PrimaryButton("Open preview", Icons.Rounded.Visibility, enabled = sel.isNotEmpty() && p != null) {
                e.run("previewOpen", obj("pid" to p!!.id, "path" to sel, "width" to width), key = "preview")
            }
        }
    }
}

/* ───────────── Virtual Device ───────────── */

@Composable
fun DeviceScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    val p = currentProject(st)
    var api by remember(st.ready) { mutableStateOf(st.cfg.optString("emulatorApi", "34")) }
    var events by remember(st.ready) { mutableStateOf(st.cfg.optInt("uiEvents", 300).toString()) }
    var shots by remember { mutableStateOf(listOf<String>()) }
    var crash by remember { mutableStateOf("") }
    val tests = st.builds.filter { it.pid == p?.id && it.kind == "test" }
    val running = tests.any { it.active } || "build${p?.id}" in busy

    SubScreen("Virtual Device", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Runs a real Android emulator in the cloud. It installs your app, taps around and reports crashes with screenshots.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (p == null) { item { Text("No project yet.") }; return@LazyColumn }
            item { Text("Android version", style = MaterialTheme.typography.titleMedium) }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("30", "33", "34").forEach { v -> FilterChip(selected = api == v, onClick = { api = v }, label = { Text("API $v") }) } } }
            item { OutlinedTextField(events, { events = it.filter(Char::isDigit).take(4) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Random taps (50–2000)") }, shape = RoundedCornerShape(16.dp)) }
            item {
                PrimaryButton(if (running) "Testing…" else "Run emulator test", Icons.Rounded.PlayArrow, enabled = !running && st.setupOk) {
                    val n = (events.toIntOrNull() ?: 300).coerceIn(50, 2000)
                    e.run("saveCfg", obj("emulatorApi" to api, "uiEvents" to n), key = "cfg") {
                        e.run("buildStart", obj("pid" to p.id, "kind" to "test", "autofix" to false), key = "build${p.id}") { r ->
                            val o = r as? JSONObject
                            e.messages.tryEmit(if (o?.optBoolean("ok") == true) "Test passed" else o?.optString("reason").orEmpty().ifBlank { "Test failed" })
                        }
                    }
                }
            }
            items(tests.take(5)) { b ->
                BuildRow(b)
                if (!b.active && b.status != BuildStatus.Queued) TextButton(onClick = {
                    e.run("deviceReports", obj("buildId" to b.id), key = "rep") { r ->
                        val o = r as JSONObject
                        shots = o.optJSONArray("shots").strings(); crash = o.optString("crash")
                        if (shots.isEmpty() && crash.isEmpty()) e.messages.tryEmit("No screenshots or crash report in this test")
                    }
                }) { Text(if ("rep" in busy) "Loading…" else "Load screenshots and crash report") }
            }
            if (crash.isNotEmpty()) item { AppCard { Text("Crash report", style = MaterialTheme.typography.titleMedium, color = Bad); Spacer(Modifier.height(6.dp)); Text(crash, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp) } }
            if (shots.isNotEmpty()) item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(shots) { b64 ->
                        val bmp = remember(b64) { runCatching { val d = Base64.decode(b64, Base64.DEFAULT); BitmapFactory.decodeByteArray(d, 0, d.size)?.asImageBitmap() }.getOrNull() }
                        if (bmp != null) Image(bmp, null, Modifier.height(380.dp).clip(RoundedCornerShape(16.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)), contentScale = ContentScale.Fit)
                    }
                }
            }
        }
    }
}
