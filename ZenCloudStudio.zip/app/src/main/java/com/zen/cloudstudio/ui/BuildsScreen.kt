package com.zen.cloudstudio.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zen.cloudstudio.obj
import org.json.JSONObject

@Composable
fun currentProject(st: StudioState): Project? {
    val pid by LocalEngine.current.selectedPid.collectAsState()
    return st.projects.firstOrNull { it.id == pid } ?: st.projects.firstOrNull()
}

@Composable
fun BuildsScreen(onSettings: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp, start = 20.dp, end = 20.dp)) {
            ScreenTitle("Builds", "Build in the cloud, track every run.")
        }
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Build Center") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("History") })
        }
        if (tab == 0) BuildCenter(onSettings) else BuildHistory { tab = 0 }
    }
}

@Composable
fun LogBox(buildId: String) {
    val e = LocalEngine.current
    var text by remember(buildId) { mutableStateOf("Loading…") }
    LaunchedEffect(buildId) { e.run("buildLog", obj("id" to buildId), key = "log$buildId") { text = (it as? JSONObject)?.optString("text").orEmpty().ifBlank { "No log saved for this build." } } }
    Text(
        text, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp,
        modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).padding(10.dp)
            .horizontalScroll(rememberScrollState())
    )
}

@Composable
private fun BuildCenter(onSettings: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    val p = currentProject(st)
    var kind by remember { mutableStateOf("debug") }
    var autoFix by remember { mutableStateOf(true) }
    var showLog by remember { mutableStateOf(false) }

    fun start(fix: Boolean, k: String) {
        val pr = p ?: return
        e.run("buildStart", obj("pid" to pr.id, "kind" to k, "autofix" to fix), key = "build${pr.id}") { r ->
            val o = r as? JSONObject
            e.messages.tryEmit(if (o?.optBoolean("ok") == true) "Build succeeded" else o?.optString("reason").orEmpty().ifBlank { "Build failed" })
        }
    }

    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (!st.setupOk) item { SetupCard(st, onSettings) }
        if (p == null) { item { Text("Create or import a project first.", color = MaterialTheme.colorScheme.onSurfaceVariant) }; return@LazyColumn }
        item { Text("Project", style = MaterialTheme.typography.titleMedium) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(st.projects) { x -> FilterChip(selected = p.id == x.id, onClick = { e.selectedPid.value = x.id }, label = { Text(x.name) }) }
            }
        }
        item { Text("Build type", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("debug", "release", "test").forEach { k ->
                    FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k.replaceFirstChar { it.uppercase() }) })
                }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Fix errors with AI", style = MaterialTheme.typography.titleMedium)
                        Text("If the build fails, AI proposes a fix. You approve it, then it rebuilds.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = autoFix, onCheckedChange = { autoFix = it })
                }
            }
        }
        val active = st.builds.firstOrNull { it.pid == p.id && it.active }
        val working = active != null || "build${p.id}" in busy
        item {
            OutlinedButton(onClick = {
                e.run("speedUp", obj("pid" to p.id), key = "speed") { r ->
                    val n = (r as? JSONObject)?.optJSONArray("changed")?.length() ?: 0
                    e.messages.tryEmit(if (n == 0) "Build settings are already fast" else "Build speed-up applied ($n change(s)). Restore point saved.")
                }
            }, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Rounded.Bolt, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(if ("speed" in busy) "Applying…" else "Speed up builds")
            }
        }
        item { PrimaryButton(if (working) "Building…" else "Start $kind build", Icons.Rounded.PlayArrow, enabled = !working && st.setupOk) { start(autoFix, kind) } }
        if (active != null) item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(active.step.ifBlank { "Preparing" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    StatusPill(active.status)
                }
                Spacer(Modifier.height(10.dp))
                if (active.total > 0) LinearProgressIndicator(progress = { active.done.toFloat() / active.total }, modifier = Modifier.fillMaxWidth().height(8.dp), strokeCap = StrokeCap.Round)
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(8.dp), strokeCap = StrokeCap.Round)
                Spacer(Modifier.height(6.dp))
                Text("You can leave the app. The build keeps running in the cloud.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { e.run("buildCancel", obj("id" to active.id), key = "cancel") }) { Text("Cancel build", color = Bad) }
            }
        }
        val last = st.builds.firstOrNull { it.pid == p.id && !it.active }
        if (active == null && last != null) item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Last build · ${last.kind}", style = MaterialTheme.typography.titleMedium)
                        Text(ago(last.started), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusPill(last.status)
                }
                if (last.summary.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(last.summary, style = MaterialTheme.typography.bodyMedium) }
                if (last.error.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(last.error, style = MaterialTheme.typography.bodyMedium, color = Bad) }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (last.status == BuildStatus.Failed && last.kind != "test") {
                        Button(onClick = { start(true, last.kind) }, enabled = !working, shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Fix with AI")
                        }
                    }
                    OutlinedButton(onClick = { showLog = !showLog }, shape = RoundedCornerShape(12.dp)) { Text(if (showLog) "Hide log" else "Show log") }
                }
                AnimatedVisibility(showLog) { Column { Spacer(Modifier.height(10.dp)); LogBox(last.id) } }
            }
        }
    }
}

@Composable
private fun BuildHistory(onRetry: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    val uri = LocalUriHandler.current
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedButton(onClick = { e.run("cleanup", key = "cleanup") { r -> e.messages.tryEmit("Removed ${(r as? JSONObject)?.optInt("n") ?: 0} old cloud file(s)") } }, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Rounded.CleaningServices, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(if ("cleanup" in busy) "Cleaning…" else "Clean old cloud files")
            }
        }
        if (st.builds.isEmpty()) item { Text("No builds yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(st.builds) { b ->
            var open by remember { mutableStateOf(false) }
            Column {
                BuildRow(b) { open = !open }
                AnimatedVisibility(open) {
                    AppCard(Modifier.padding(top = 8.dp)) {
                        Text("${b.project} · ${b.kind} · attempt ${b.attempt} · ${ago(b.started)}", style = MaterialTheme.typography.bodyMedium)
                        if (b.summary.isNotBlank()) Text(b.summary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (b.error.isNotBlank()) Text(b.error, style = MaterialTheme.typography.bodyMedium, color = Bad)
                        Spacer(Modifier.height(10.dp))
                        LogBox(b.id)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { e.selectedPid.value = b.pid; onRetry() }, shape = RoundedCornerShape(12.dp)) { Text("Build again") }
                            if (b.url.isNotBlank()) OutlinedButton(onClick = { uri.openUri(b.url) }, shape = RoundedCornerShape(12.dp)) { Text("GitHub") }
                        }
                    }
                }
            }
        }
    }
}
