/* AI keys, endpoints and models. This is the only place to change them.
 * TESTING ONLY: anyone who has this source or the APK can read these keys.
 * Before a public release: move them to your backend, remove them here and revoke them. */
window.AI_CONFIG = {
  // Tried from top to bottom. If a key or model fails, the next one is used.
  providers: [
    { name: 'Gemini', type: 'gemini', url: 'https://generativelanguage.googleapis.com/v1beta/models/',
      models: ['gemini-3.8-flash', 'gemini-3.6-flash'],
      keys: ['AQ.Ab8RN6LLikeClSlfB22z9QEDpSHmD9ofDdaqJ_CmoTy0harjAQ',
             'AQ.Ab8RN6J3Vvu-1B9fO6XLWEyWVTkdiQ7GxvLvHcVjwSHH4TeXpA'] },
    { name: 'OpenRouter', type: 'openai', url: 'https://openrouter.ai/api/v1/chat/completions',
      models: ['openrouter/auto', 'openrouter/free'],
      keys: ['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',
             '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',
             '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'] },
    { name: 'Groq', type: 'openai', url: 'https://api.groq.com/openai/v1/chat/completions',
      models: ['openai/gpt-oss-120b', 'openai/gpt-oss-20b'],
      keys: ['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',
             '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',
             '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',
             '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'] },
    { name: 'Pollinations', type: 'openai', url: 'https://gen.pollinations.ai/v1/chat/completions',
      models: ['openai'],
      keys: ['sk_NP0MH86CfM8tsO6NkCgcfkEJKpp20YHC'] }
  ],
  // Web search, used once while planning a new app.
  search: { url: 'https://api.tavily.com/search', keys: ['tvly-2Cvcvv-gqxg67LuhzCruISzbl0e8GLTmxDMpw0swBquYcjNv6'] }
};
