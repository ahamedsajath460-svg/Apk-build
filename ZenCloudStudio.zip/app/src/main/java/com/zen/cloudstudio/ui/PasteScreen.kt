package com.zen.cloudstudio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zen.cloudstudio.obj
import org.json.JSONArray
import org.json.JSONObject

private class PF(path: String = "", text: String = "") {
    var path by mutableStateOf(path)
    var text by mutableStateOf(text)
}

@Composable
fun PasteScreen(onBack: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    val clip = LocalClipboardManager.current
    val blocks = remember { mutableStateListOf(PF()) }
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    val working = "paste" in busy

    fun go(build: Boolean) {
        val arr = JSONArray()
        blocks.forEach { arr.put(JSONObject().put("path", it.path).put("text", it.text)) }
        e.run("pasteCode", obj("name" to name.trim(), "pkg" to pkg.trim(), "files" to arr), key = "paste") { r ->
            val o = r as JSONObject
            val pid = o.optString("pid")
            e.selectedPid.value = pid
            e.messages.tryEmit("Project created: ${o.optString("name")} (${o.optInt("files")} files)" + if (o.optBoolean("web")) " · web app" else "")
            if (build) {
                e.nav.tryEmit("builds")
                e.run("buildStart", obj("pid" to pid, "kind" to "debug", "autofix" to true), key = "build$pid") { b ->
                    val ok = (b as? JSONObject)?.optBoolean("ok") == true
                    e.messages.tryEmit(if (ok) "APK is ready. Download it here." else (b as? JSONObject)?.optString("reason").orEmpty().ifBlank { "Build failed" })
                    if (ok) e.nav.tryEmit("apks")
                }
            } else e.nav.tryEmit("workspace")
        }
    }

    SubScreen("Paste Code", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                AppCard {
                    Text("Paste your code, get an APK", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Works with Android code: Kotlin, Java, XML layouts, Gradle files, and web apps (HTML, CSS, JS) that run inside an app. " +
                            "Leave the file name empty and it is detected from the code.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (!st.setupOk) item { SetupCard(st) { e.nav.tryEmit("settings") } }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text("App name") }, shape = RoundedCornerShape(16.dp))
                    OutlinedTextField(pkg, { pkg = it }, Modifier.weight(1f), singleLine = true, label = { Text("Package (optional)") }, shape = RoundedCornerShape(16.dp))
                }
            }
            items(blocks.size) { i ->
                val b = blocks[i]
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(b.path, { b.path = it }, Modifier.weight(1f), singleLine = true, label = { Text("File ${i + 1} name (optional)") }, shape = RoundedCornerShape(14.dp))
                        if (blocks.size > 1) IconButton(onClick = { blocks.removeAt(i) }) { Icon(Icons.Rounded.Delete, "Remove", tint = Bad) }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        b.text, { b.text = it }, Modifier.fillMaxWidth(), minLines = 8, maxLines = 14, shape = RoundedCornerShape(14.dp),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp),
                        placeholder = { Text("Paste code here") }
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { clip.getText()?.text?.let { b.text = it } }) {
                        Icon(Icons.Rounded.ContentPaste, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Paste from clipboard")
                    }
                }
            }
            item { SecondaryButton("Add another file", Icons.Rounded.NoteAdd) { blocks.add(PF()) } }
            item {
                PrimaryButton(if (working) "Working…" else "Create and build APK", Icons.Rounded.RocketLaunch, enabled = !working && st.setupOk && blocks.any { it.text.isNotBlank() }) { go(true) }
            }
            item { SecondaryButton("Create project only", Icons.Rounded.FolderOpen) { if (!working && blocks.any { it.text.isNotBlank() }) go(false) } }
        }
    }
}
