/* Zen AI Cloud Studio - import: bring your own code. A ZIP (Android Studio project, or just source files) or loose files
 * (.kt .java .xml .gradle images fonts…) become a project that builds to an APK like any other.
 *   unzip   - offline ZIP reader (no internet, no library): central directory + the browser's DecompressionStream
 *   analyze - decides what the files are: whole project / sources without Gradle files / loose files, skips what must not
 *             be uploaded (keystores, local.properties, build output, wrapper jars…) and says why
 *   place   - loose files go to the folder Android expects (Kotlin by package, layouts, drawables, values, images…)
 *   create  - makes the project (text files + binary resources) ready for Build Center
 * Pure logic, tested in Node. */
(function (W) {
  'use strict';
  var CS = W.CloudStudio; if (!CS || !CS.core || !CS.gen || CS.importer) return;
  var U = CS.u, db = CS.db;
  var IMP = CS.importer = {};
  var MAX_ENTRY = 5 * 1024 * 1024, MAX_TOTAL = 80 * 1024 * 1024, MAX_ENTRIES = 5000;

  /* ======================= ZIP reader ======================= */
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }

  /** Inflate raw deflate data, giving up when the result is bigger than `max` (zip-bomb guard). */
  function inflate(data, max) {
    if (typeof DecompressionStream === 'undefined') return Promise.reject(CS.Err('This phone\'s browser engine is too old to open ZIP files. Update "Android System WebView" in the Play Store, or send the files one by one.', 'zip'));
    var rd = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader(), parts = [], n = 0;
    function pump() {
      return rd.read().then(function (r) {
        if (r.done) { var out = new Uint8Array(n), o = 0; parts.forEach(function (q) { out.set(q, o); o += q.length; }); return out; }
        n += r.value.length; if (n > max) { try { rd.cancel(); } catch (e) { } return null; }
        parts.push(r.value); return pump();
      });
    }
    return pump();
  }

  /** buf: ArrayBuffer | Uint8Array. Resolves { entries: { path: Uint8Array }, skipped: [{path, why}] } */
  IMP.unzip = function (buf) {
    return Promise.resolve().then(function () {
      var b = buf instanceof Uint8Array ? buf : new Uint8Array(buf), n = b.length, eocd = -1;
      for (var i = n - 22; i >= Math.max(0, n - 22 - 65535); i--) if (u32(b, i) === 0x06054b50) { eocd = i; break; }
      if (eocd < 0) throw CS.Err('This is not a ZIP file (or it is damaged).', 'zip');
      var count = u16(b, eocd + 10), cdOff = u32(b, eocd + 16);
      if (count === 0xFFFF || cdOff === 0xFFFFFFFF) throw CS.Err('ZIP64 files are not supported. Make a normal ZIP of the project.', 'zip');
      if (count > MAX_ENTRIES) throw CS.Err('The ZIP has more than ' + MAX_ENTRIES + ' files. Zip only the project folder (without build output).', 'zip');
      var list = [], skipped = [], declared = 0, dec = new TextDecoder('utf-8'), p = cdOff;
      for (var k = 0; k < count; k++) {
        if (p + 46 > n || u32(b, p) !== 0x02014b50) throw CS.Err('The ZIP index is damaged.', 'zip');
        var flags = u16(b, p + 8), method = u16(b, p + 10), csize = u32(b, p + 20), usize = u32(b, p + 24), nl = u16(b, p + 28), el = u16(b, p + 30), cl = u16(b, p + 32), lho = u32(b, p + 42);
        var name = dec.decode(b.subarray(p + 46, p + 46 + nl)).replace(/\\/g, '/'); p += 46 + nl + el + cl;
        if (/\/$/.test(name)) continue;
        if (name[0] === '/' || /(^|\/)\.\.(\/|$)/.test(name) || /^[A-Za-z]:/.test(name)) { skipped.push({ path: name, why: 'unsafe path' }); continue; }
        if (flags & 1) { skipped.push({ path: name, why: 'password protected' }); continue; }
        if (method !== 0 && method !== 8) { skipped.push({ path: name, why: 'unsupported compression' }); continue; }
        declared += usize; if (declared > MAX_TOTAL) throw CS.Err('The ZIP is larger than 80 MB when opened. Zip only the project folder (without build output).', 'zip');
        list.push({ name: name, method: method, csize: csize, usize: usize, lho: lho });
      }
      var entries = {}, i2 = 0;
      function next() {
        if (i2 >= list.length) return Promise.resolve({ entries: entries, skipped: skipped });
        var e = list[i2++];
        if (e.usize > MAX_ENTRY) { skipped.push({ path: e.name, why: 'larger than 5 MB' }); return next(); }
        if (e.lho + 30 > n || u32(b, e.lho) !== 0x04034b50) { skipped.push({ path: e.name, why: 'damaged entry' }); return next(); }
        var ds = e.lho + 30 + u16(b, e.lho + 26) + u16(b, e.lho + 28), raw = b.subarray(ds, ds + e.csize);
        if (e.method === 0) { entries[e.name] = raw.slice(); return next(); }
        return inflate(raw, MAX_ENTRY).then(function (out) { if (out) entries[e.name] = out; else skipped.push({ path: e.name, why: 'larger than 5 MB' }); return next(); }, function (err) { if (err && err.code === 'zip') throw err; skipped.push({ path: e.name, why: 'damaged entry' }); return next(); });
      }
      return next();
    });
  };

  /* ======================= what is each file? ======================= */
  var IGNORE_DIR = /(^|\/)(\.git|\.github|\.idea|\.gradle|\.vscode|\.cxx|\.externalNativeBuild|captures|build|node_modules|__MACOSX|\.fleet)(\/|$)/;
  var NEVER = [
    [/\.(jks|keystore|p12|pfx|pem|key|crt|cer)$/i, 'signing key / certificate: never uploaded (Zen AI signs with its own CLOUD_* secrets)'],
    [/(^|\/)local\.properties$/, 'machine specific (SDK path)'],
    [/(^|\/)(gradlew\.bat|gradlew|gradle-wrapper\.jar|gradle-wrapper\.properties)$/, 'Gradle wrapper (Zen AI builds with its own pinned Gradle)'],
    [/\.(iml)$/i, 'IDE file'], [/(^|\/)(\.DS_Store|Thumbs\.db)$/, 'system file'],
    [/\.(apk|aab|jar|aar|so|dex|class|zip|7z|rar|mp4|mov|pdf|db|sqlite)$/i, 'binary type that is not uploaded'],
    [/\.(ya?ml)$/i, 'workflow / YAML files are not allowed inside a project']
  ];
  function utf8(u8) { try { return new TextDecoder('utf-8', { fatal: true }).decode(u8); } catch (e) { return null; } }
  function b64(u8) { var s = '', i; for (i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  IMP.b64 = b64;

  /** entries: { path: Uint8Array | string } -> { text: {rel: str}, bin: {rel: b64}, skipped: [{path, why}] } (paths unchanged, only classified) */
  function safe(p) { return p.replace(/[^A-Za-z0-9_.\-\/]/g, '_'); } // type check only; the real name check happens once the project root is known
  IMP.classify = function (entries) {
    var text = {}, bin = {}, skipped = [], binTotal = 0;
    Object.keys(entries).sort().forEach(function (path) {
      var v = entries[path], rel = path.replace(/^\.\//, '');
      if (IGNORE_DIR.test(rel) && !(/(^|\/)src\//.test(rel) && !/(^|\/)(\.git|\.idea|node_modules|__MACOSX)(\/|$)/.test(rel))) { skipped.push({ path: rel, why: 'build output / IDE / version-control folder', quiet: true }); return; }
      for (var i = 0; i < NEVER.length; i++) if (NEVER[i][0].test(rel)) { skipped.push({ path: rel, why: NEVER[i][1] }); return; }
      if (rel.length > 240) { skipped.push({ path: rel, why: 'path too long' }); return; }
      if (typeof v === 'string') { if (CS.okRel(safe(rel)) && v.length <= CS.LIMITS.file) text[rel] = v; else skipped.push({ path: rel, why: 'file type or size not accepted' }); return; }
      if (/\.(png|webp|jpe?g|gif|ttf|otf|ico|ogg|mp3|wav|m4a)$/i.test(rel)) {
        if (v.length > CS.LIMITS.bin) { skipped.push({ path: rel, why: 'larger than ' + Math.round(CS.LIMITS.bin / 1e5) / 10 + ' MB' }); return; }
        if (binTotal + v.length > CS.LIMITS.binTotal) { skipped.push({ path: rel, why: 'too many images / fonts in total (12 MB max)' }); return; }
        binTotal += v.length; bin[rel] = b64(v); return;
      }
      if (!CS.okRel(safe(rel))) { skipped.push({ path: rel, why: 'file type is not needed for a build' }); return; }
      var t = utf8(v); if (t == null) { skipped.push({ path: rel, why: 'not UTF-8 text' }); return; }
      if (t.length > CS.LIMITS.file) { skipped.push({ path: rel, why: 'larger than 400 KB' }); return; }
      text[rel] = t;
    });
    return { text: text, bin: bin, skipped: skipped };
  };

  /* ======================= which kind of upload is it? ======================= */
  function dirOf(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function baseOf(p) { return p.slice(p.lastIndexOf('/') + 1); }
  function depth(p) { return p.split('/').length; }
  var LIBMAP = [['androidx.recyclerview', 'recyclerview'], ['androidx.lifecycle', 'lifecycle'], ['androidx.navigation', 'navigation'], ['androidx.room', 'room'], ['retrofit2', 'retrofit'], ['com.google.gson', 'gson'], ['kotlinx.coroutines', 'coroutines'], ['coil.', 'coil']];
  function guessLibs(text) { var libs = {}; Object.keys(text).forEach(function (k) { if (/\.(kt|java)$/.test(k)) LIBMAP.forEach(function (m) { if (text[k].indexOf(m[0]) >= 0) libs[m[1]] = 1; }); }); return Object.keys(libs); }
  function pkgOfCode(text) { var found = ''; Object.keys(text).some(function (k) { if (!/\.(kt|java)$/.test(k)) return false; var m = /^\s*package\s+([\w.]+)/m.exec(text[k]); if (m && CS.okPackage(m[1])) { found = m[1]; return true; } return false; }); return found; }

  /**
   * Decide what was uploaded. Returns
   *  { mode: 'project' | 'sources' | 'loose', files: {rel: text}, bins: {rel: b64}, skipped, notes: [], name, pkg, error }
   *  project: it has settings.gradle(.kts): used as is (its own Gradle files, any modules)
   *  sources: it has an AndroidManifest.xml but no Gradle project: Zen AI adds the known-good Gradle files around it
   *  loose:   just files: use IMP.place() to put them into a project
   */
  /** after the project root is known: drop files whose final path Android/GitHub cannot take, and say why */
  function finalCheck(res) {
    ['files', 'bins'].forEach(function (w) { Object.keys(res[w]).forEach(function (k) { var ok = w === 'files' ? CS.okRel(k) : CS.okBinRel(k); if (!ok) { delete res[w][k]; res.skipped.push({ path: k, why: /[^A-Za-z0-9_.\-\/]/.test(k) ? 'file or folder name has spaces or characters Android does not allow: rename it' : 'path or file type not accepted' }); } }); });
  }
  IMP.analyze = function (entries, opt) {
    opt = opt || {}; var notes = [], cl = IMP.classify(entries), paths = Object.keys(cl.text).concat(Object.keys(cl.bin));
    var res = { mode: 'loose', files: {}, bins: {}, skipped: cl.skipped, notes: notes, name: opt.name || '', pkg: '', error: '' };
    var settings = Object.keys(cl.text).filter(function (k) { return /(^|\/)settings\.gradle(\.kts)?$/.test(k); }).sort(function (a, b) { return depth(a) - depth(b); });
    if (settings.length) {
      var root = dirOf(settings[0]), pre = root ? root + '/' : '';
      if (settings.filter(function (k) { return depth(k) === depth(settings[0]); }).length > 1) notes.push('The ZIP holds more than one project; only "' + (root || '/') + '" was imported.');
      paths.forEach(function (k) { if (pre && k.indexOf(pre) !== 0) { res.skipped.push({ path: k, why: 'outside the project folder', quiet: true }); return; } var rel = k.slice(pre.length); if (cl.text[k] != null) res.files[rel] = cl.text[k]; else res.bins[rel] = cl.bin[k]; });
      res.mode = 'project'; finalCheck(res);
      var st = res.files['settings.gradle.kts'] || res.files['settings.gradle'] || '', m = /rootProject\.name\s*=\s*["']([^"']+)["']/.exec(st); if (m && !opt.name) res.name = m[1];
      var app = Object.keys(res.files).filter(function (k) { return /(^|\/)build\.gradle(\.kts)?$/.test(k) && /com\.android\.application/.test(res.files[k].replace(/[^\n]*apply\s+false[^\n]*/g, '')); })[0];
      if (!app) res.error = 'No app module was found (a build.gradle with the "com.android.application" plugin). A library alone cannot be built into an APK.';
      else { var g = res.files[app], id = /applicationId\s*[=\s]\s*["']([\w.]+)["']/.exec(g) || /namespace\s*[=\s]\s*["']([\w.]+)["']/.exec(g); if (id) res.pkg = id[1]; }
      var agp = /com\.android\.application["']?\s*(?:\)\s*)?version\s*["']([\d.]+)["']/.exec(Object.keys(res.files).map(function (k) { return /(^|\/)(build|settings)\.gradle(\.kts)?$/.test(k) ? res.files[k] : ''; }).join('\n')) || /com\.android\.tools\.build:gradle:([\d.]+)/.exec(res.files['build.gradle'] || res.files['build.gradle.kts'] || '');
      if (agp && +agp[1].split('.')[0] * 100 + +agp[1].split('.')[1] < 802) notes.push('This project uses Android Gradle Plugin ' + agp[1] + '. Zen AI builds with Gradle 8.7, which needs plugin 8.2 or newer. If the build fails on this, the AI fix can update it.');
      if (Object.keys(res.files).some(function (k) { return /(^|\/)(buildSrc)\//.test(k); })) notes.push('The project has a buildSrc folder (build code). It is allowed, but check it is yours.');
      return res;
    }
    var man = Object.keys(cl.text).filter(function (k) { return /(^|\/)AndroidManifest\.xml$/.test(k); }).sort(function (a, b) { return depth(a) - depth(b); })[0];
    if (man) {
      var base = dirOf(man), mod = /(^|\/)src\/main$/.test(base) ? base.replace(/(^|\/)?src\/main$/, '') : '', from = base ? base + '/' : '';
      paths.forEach(function (k) { if (from && k.indexOf(from) !== 0) { res.skipped.push({ path: k, why: 'outside the app folder', quiet: true }); return; } var rel = 'app/src/main/' + k.slice(from.length); if (cl.text[k] != null) res.files[rel] = cl.text[k]; else res.bins[rel] = cl.bin[k]; });
      var mp = /package\s*=\s*"([\w.]+)"/.exec(cl.text[man]); res.pkg = (mp && CS.okPackage(mp[1]) && mp[1]) || pkgOfCode(res.files) || '';
      finalCheck(res); res.mode = 'sources'; notes.push('There was no Gradle project in the upload, so Zen AI added its standard Gradle files (Android Gradle Plugin 8.5, Kotlin 1.9, minSdk 26, targetSdk 34) around your code.');
      if (mod) notes.push('Source folder "' + mod + '" was mapped to app/.');
      return res;
    }
    paths.forEach(function (k) { if (cl.text[k] != null) res.files[k] = cl.text[k]; else res.bins[k] = cl.bin[k]; });
    res.pkg = pkgOfCode(res.files); return res;
  };

  /* ======================= loose files -> the folder Android expects ======================= */
  var DRAWABLE_ROOT = /^<(vector|shape|selector|layer-list|ripple|bitmap|animated-vector|inset|rotate|scale|level-list|transition|clip|animation-list)\b/;
  function resName(n) { var ext = /\.[^.]+$/.exec(n), b = n.replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9_]/g, '_').replace(/^[0-9_]+/, ''); return (b || 'file') + (ext ? ext[0].toLowerCase() : ''); }
  /** Where does a loose text file go? (project package pkg). Returns a path, or '' when it cannot be told. */
  IMP.guessPath = function (name, content, pkg) {
    var n = baseOf(name), main = 'app/src/main/', c = String(content || '');
    if (/^(app|[A-Za-z0-9_]+)\/src\/main\//.test(name) || /^(app|[A-Za-z0-9_]+)\/(build\.gradle(\.kts)?|proguard-rules\.pro)$/.test(name)) return name;
    if (/\.(kt|java)$/.test(n)) { var m = /^\s*package\s+([\w.]+)/m.exec(c), pk = (m && m[1]) || pkg || 'com.example.app'; return main + 'java/' + pk.replace(/\./g, '/') + '/' + n; }
    if (/\.xml$/i.test(n)) {
      var body = c.replace(/^\s*<\?xml[^>]*\?>\s*/, '').replace(/<!--[\s\S]*?-->\s*/g, '').trim();
      if (/^<manifest\b/.test(body)) return main + 'AndroidManifest.xml';
      if (/^<resources\b/.test(body)) return main + 'res/values/' + (/\.xml$/.test(n) ? resName(n) : n);
      if (/^<menu\b/.test(body)) return main + 'res/menu/' + resName(n);
      if (/^<navigation\b/.test(body)) return main + 'res/navigation/' + resName(n);
      if (/^<adaptive-icon\b/.test(body)) return main + 'res/mipmap-anydpi-v26/' + resName(n);
      if (DRAWABLE_ROOT.test(body)) return main + 'res/drawable/' + resName(n);
      if (/^<(PreferenceScreen|paths|network-security-config|full-backup-content|data-extraction-rules|locale-config|shortcuts|automotive)\b/.test(body)) return main + 'res/xml/' + resName(n);
      if (/^<(animator|objectAnimator|set)\b/.test(body)) return main + 'res/anim/' + resName(n);
      return main + 'res/layout/' + resName(n);
    }
    if (/\.(png|jpe?g|webp|gif)$/i.test(n)) return main + 'res/drawable/' + resName(n);
    if (/\.(ttf|otf)$/i.test(n)) return main + 'res/font/' + resName(n);
    if (/\.(ogg|mp3|wav|m4a)$/i.test(n)) return main + 'res/raw/' + resName(n);
    if (/^settings\.gradle(\.kts)?$/.test(n) || /^gradle\.properties$/.test(n)) return n;
    if (/\.gradle(\.kts)?$/.test(n)) return /com\.android\.application/.test(c) ? 'app/' + n : n;
    if (/\.(json|txt|md|html|css|js|svg|toml)$/i.test(n)) return main + 'assets/' + n;
    return '';
  };

  /** Loose files -> plan with one path each (the user can still change them). cl = IMP.classify result. */
  IMP.place = function (cl, pkg) {
    var rows = [];
    Object.keys(cl.text).forEach(function (k) { var to = IMP.guessPath(k, cl.text[k], pkg); rows.push({ from: k, to: to, kind: 'text' }); });
    Object.keys(cl.bin).forEach(function (k) { var to = IMP.guessPath(k, '', pkg); rows.push({ from: k, to: to, kind: 'bin' }); });
    return rows;
  };

  /** Turn placed rows into file maps. rows: [{from, to, kind}], cl: classify result. Skips rows with an empty or unsafe target. */
  IMP.apply = function (rows, cl) {
    var files = {}, bins = {}, skipped = [];
    rows.forEach(function (r) {
      var to = String(r.to || '').trim().replace(/^\/+/, '');
      if (!to) { skipped.push({ path: r.from, why: 'no target folder' }); return; }
      if (r.kind === 'text') { if (!CS.okRel(to)) { skipped.push({ path: r.from, why: 'target path not allowed: ' + to }); return; } files[to] = cl.text[r.from]; }
      else { if (!CS.okBinRel(to)) { skipped.push({ path: r.from, why: 'target path not allowed: ' + to + ' (images and fonts belong in res/ or assets/)' }); return; } bins[to] = cl.bin[r.from]; }
    });
    return { files: files, bins: bins, skipped: skipped };
  };

  /* ======================= build the final project ======================= */
  /** Fills in what a "sources" / "loose" upload lacks, using the standard scaffold. Returns { files, bins, notes, pkg, name }. */
  IMP.complete = function (plan, o) {
    var notes = (plan.notes || []).slice(), files = Object.assign({}, plan.files), bins = Object.assign({}, plan.bins), name = String(o.name || plan.name || 'Imported App').replace(/[^A-Za-z0-9 _-]/g, '').trim().slice(0, 40) || 'Imported App';
    var pkg = o.pkg || plan.pkg || ''; if (!CS.okPackage(pkg)) pkg = pkgOfCode(files) || CS.guessPackage(name);
    if (plan.mode === 'project') return { files: files, bins: bins, notes: notes, pkg: plan.pkg || pkg, name: name };
    var libs = guessLibs(files), sc = CS.scaffold({ name: name, pkg: pkg, libs: libs }), hasManifest = !!files['app/src/main/AndroidManifest.xml'];
    var made = {};
    ['settings.gradle.kts', 'build.gradle.kts', 'gradle.properties', '.gitignore'].forEach(function (k) { if (!files[k] && !files[k.replace('.kts', '')]) { files[k] = sc[k]; made[k] = 1; } });
    if (!files['app/build.gradle.kts'] && !files['app/build.gradle']) { files['app/build.gradle.kts'] = sc['app/build.gradle.kts']; made['app/build.gradle.kts'] = 1; }
    if (libs.length) notes.push('Libraries added from your imports: ' + libs.join(', ') + '.');
    if (!hasManifest) {
      // the starter manifest, but launching the activity the user wrote (if there is exactly one)
      var acts = []; Object.keys(files).forEach(function (k) { if (!/\.(kt|java)$/.test(k)) return; var m = /class\s+(\w+)\s*:\s*(?:\w+\.)*(AppCompatActivity|ComponentActivity|FragmentActivity|Activity)\b/.exec(files[k]), pk = /^\s*package\s+([\w.]+)/m.exec(files[k]); if (m && pk) acts.push({ cls: m[1], pkg: pk[1], file: k }); });
      var man = sc['app/src/main/AndroidManifest.xml'];
      if (acts.length) { var a = acts.filter(function (x) { return x.cls === 'MainActivity'; })[0] || acts[0]; man = man.replace('android:name=".MainActivity"', 'android:name="' + a.pkg + '.' + a.cls + '"'); if (acts.length > 1) notes.push(acts.length + ' activities were found; "' + a.cls + '" opens first. Add the others to AndroidManifest.xml.'); if (a.pkg !== pkg && CS.okPackage(a.pkg)) { pkg = a.pkg; sc = CS.scaffold({ name: name, pkg: pkg, libs: libs }); ['app/build.gradle.kts', 'settings.gradle.kts'].forEach(function (k) { if (made[k]) files[k] = sc[k]; }); } }
      else notes.push('No Activity class and no AndroidManifest.xml were found, so the starter app opens. Add your Activity and a manifest to change that.');
      files['app/src/main/AndroidManifest.xml'] = man;
      ['app/src/main/res/values/themes.xml', 'app/src/main/res/values/colors.xml', 'app/src/main/res/values/strings.xml'].forEach(function (k) { if (!files[k]) files[k] = sc[k]; });
      if (!bins && !Object.keys(files).some(function (k) { return /res\/mipmap/.test(k); })) { /* never */ }
      ['app/src/main/res/mipmap-anydpi/ic_launcher.xml', 'app/src/main/res/drawable/ic_launcher_fg.xml'].forEach(function (k) { if (!files[k] && !Object.keys(files).some(function (q) { return /res\/(mipmap|drawable)[^/]*\/ic_launcher(_fg)?\./.test(q); }) && !Object.keys(bins).some(function (q) { return /res\/mipmap[^/]*\/ic_launcher\./.test(q); })) files[k] = sc[k]; });
      var mainAct = 'app/src/main/java/' + pkg.replace(/\./g, '/') + '/MainActivity.kt';
      if (!files[mainAct] && !acts.length) { files[mainAct] = sc[mainAct]; files['app/src/main/res/layout/activity_main.xml'] = files['app/src/main/res/layout/activity_main.xml'] || sc['app/src/main/res/layout/activity_main.xml']; }
    } else {
      // user's own manifest: make sure the theme / icon it points to exist in some form so the build does not die on a missing resource
      var mf = files['app/src/main/AndroidManifest.xml'], mm = /android:theme="@style\/([\w.]+)"/.exec(mf);
      if (mm && !Object.keys(files).some(function (k) { return /res\/values[^/]*\/[^/]+\.xml$/.test(k) && new RegExp('<style\\s+name="' + mm[1].replace(/\./g, '\\.') + '"').test(files[k]); })) notes.push('The manifest uses the theme "' + mm[1] + '" but no styles file defines it. The AI fix can add it if the build stops.');
    }
    return { files: files, bins: bins, notes: notes, pkg: pkg, name: name };
  };

  /** Create the project from a completed plan. Resolves the project record (dirty, ready for Build Center). */
  IMP.create = function (c) {
    if (!Object.keys(c.files).length) return Promise.reject(CS.Err('There are no files to import.', 'arg'));
    return CS.newProject({ name: c.name, pkg: c.pkg, files: c.files }).then(function (p) { return CS.bin.set(p.project_id, c.bins || {}).then(function () { p.dirty = true; return db.save(); }).then(function () { return p; }); });
  };

  /** Add files to an existing project (text overwrites by path; a snapshot is kept first). Resolves { added, replaced }. */
  IMP.addTo = function (p, applied) {
    return CS.files.get(p.project_id).then(function (cur) {
      var added = 0, replaced = 0; Object.keys(applied.files).forEach(function (k) { if (cur[k] != null) replaced++; else added++; });
      return CS.files.snap(p.project_id, 'Before adding ' + (Object.keys(applied.files).length + Object.keys(applied.bins).length) + ' file(s)', U.clone(cur)).catch(function () { }).then(function () { return CS.files.set(p.project_id, Object.assign({}, cur, applied.files)); })
        .then(function () { return CS.bin.get(p.project_id); }).then(function (b) { Object.keys(applied.bins).forEach(function (k) { if (b[k] != null) replaced++; else added++; }); return CS.bin.set(p.project_id, Object.assign({}, b, applied.bins)); })
        .then(function () { p.dirty = true; db.projects.touch(p); return db.save(); }).then(function () { return { added: added, replaced: replaced }; });
    });
  };

  /** Read what the user picked: File objects (zip or loose). Resolves { entries, skipped, zipName } */
  IMP.read = function (fileList) {
    var files = Array.prototype.slice.call(fileList || []), entries = {}, skipped = [], zipName = '', i = 0;
    if (!files.length) return Promise.reject(CS.Err('No file was chosen.', 'arg'));
    function one() {
      if (i >= files.length) return Promise.resolve({ entries: entries, skipped: skipped, zipName: zipName });
      var f = files[i++];
      return f.arrayBuffer().then(function (buf) {
        if (/\.zip$/i.test(f.name) || (new Uint8Array(buf, 0, 4)[0] === 0x50 && new Uint8Array(buf, 0, 4)[1] === 0x4b)) {
          zipName = zipName || f.name.replace(/\.zip$/i, '');
          return IMP.unzip(buf).then(function (z) { Object.keys(z.entries).forEach(function (k) { entries[k] = z.entries[k]; }); skipped = skipped.concat(z.skipped); });
        }
        var key = (f.webkitRelativePath || f.name).replace(/\\/g, '/'); if (entries[key]) key = 'dup' + i + '_' + key;
        if (f.size > MAX_ENTRY) { skipped.push({ path: key, why: 'larger than 5 MB' }); return; }
        entries[key] = new Uint8Array(buf);
      }).then(one);
    }
    return one();
  };
})(typeof window !== 'undefined' ? window : globalThis);
