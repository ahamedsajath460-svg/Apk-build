package com.zen.cloudstudio

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.zen.cloudstudio.ui.Proposal
import com.zen.cloudstudio.ui.StudioState
import com.zen.cloudstudio.ui.parseProposal
import com.zen.cloudstudio.ui.parseState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream

class EngineError(message: String) : Exception(message)

fun obj(vararg p: Pair<String, Any?>): JSONObject = JSONObject().also { o -> p.forEach { o.put(it.first, it.second) } }

/**
 * Runs the proven Cloud Studio logic (GitHub, AI, builds, import) in a hidden WebView and gives the native Compose
 * screens a small suspend API. The user never sees the WebView; every pixel on screen is Jetpack Compose.
 */
class Engine(private val act: AppCompatActivity) {
    val web = WebView(act)
    val state = MutableStateFlow(StudioState())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val nav = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val proposal = MutableStateFlow<Proposal?>(null)
    val busy = MutableStateFlow<Set<String>>(emptySet())
    val selectedPid = MutableStateFlow("")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ready = CompletableDeferred<Unit>()
    private val pending = HashMap<String, CompletableDeferred<Pair<Boolean, String>>>()
    private var seq = 0
    private var refresher: Job? = null
    private var importPid: String? = null

    private val picker = act.registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importUris(uris)
    }

    class JsApi(private val e: Engine) {
        @JavascriptInterface fun done(id: String, ok: Boolean, json: String) { e.scope.launch { e.pending.remove(id)?.complete(ok to json) } }
        @JavascriptInterface fun event(kind: String, json: String) { e.scope.launch { e.onEvent(kind, json) } }
        @JavascriptInterface fun toast(m: String) { e.scope.launch { e.messages.tryEmit(m) } }
    }

    fun start() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        val bridge = CloudBridge(act) { web }
        saveDefaultToken(bridge)
        web.addJavascriptInterface(bridge, "A2ZCloud")
        web.addJavascriptInterface(JsApi(this), "ZenEngine")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (request.url.host != HOST) return null
                val name = request.url.lastPathSegment ?: ""
                if (name !in PAGES) return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                val type = if (name.endsWith(".js")) "text/javascript" else "text/html"
                return WebResourceResponse(type, "UTF-8", act.assets.open(name))
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.url.host != HOST
        }
        web.alpha = 0f
        act.addContentView(web, ViewGroup.LayoutParams(1, 1))
        web.loadUrl("https://$HOST/engine.html")
    }

    fun stop() { scope.cancel(); web.destroy() }

    private fun onEvent(kind: String, json: String) {
        when (kind) {
            "ready" -> { ready.complete(Unit); refresh(0) }
            "proposal" -> proposal.value = parseProposal(JSONObject(json))
            else -> refresh(250)
        }
    }

    fun refresh(delayMs: Long = 0) {
        refresher?.cancel()
        refresher = scope.launch {
            delay(delayMs)
            try { state.value = parseState(call("snapshot") as JSONObject) } catch (_: Exception) { }
        }
    }

    suspend fun call(name: String, args: JSONObject = JSONObject()): Any? {
        ready.await()
        val id = "c${++seq}"
        val d = CompletableDeferred<Pair<Boolean, String>>()
        pending[id] = d
        web.evaluateJavascript("ZE.call(${JSONObject.quote(id)},${JSONObject.quote(name)},${JSONObject.quote(args.toString())})", null)
        val (ok, json) = d.await()
        if (!ok) throw EngineError(JSONObject(json).optString("message", "Something went wrong"))
        val v = JSONTokener(json).nextValue()
        return if (v == JSONObject.NULL) null else v
    }

    /** Fire-and-forget call that lives as long as the app, not the screen. Errors show as a message. */
    fun run(name: String, args: JSONObject = JSONObject(), key: String = name, onOk: (Any?) -> Unit = {}) {
        scope.launch {
            busy.update { it + key }
            try { onOk(call(name, args)) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { messages.tryEmit(e.message ?: "Something went wrong") }
            finally { busy.update { it - key } }
        }
    }

    fun answerProposal(yes: Boolean) {
        val p = proposal.value ?: return
        proposal.value = null
        run("answer", obj("id" to p.id, "yes" to yes), key = "answer")
    }

    fun pickImport(pid: String?) { importPid = pid; picker.launch(arrayOf("*/*")) }

    private fun importUris(uris: List<Uri>) {
        scope.launch {
            busy.update { it + "import" }
            try {
                val arr = JSONArray(); var total = 0L
                withContext(Dispatchers.IO) {
                    for (u in uris) {
                        val bytes = act.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: continue
                        total += bytes.size
                        if (total > 30_000_000) throw EngineError("Files are too large (30 MB max at once).")
                        arr.put(JSONObject().put("name", displayName(u)).put("b64", Base64.encodeToString(bytes, Base64.NO_WRAP)))
                    }
                }
                messages.tryEmit("Reading…")
                val a = JSONObject().put("files", arr)
                importPid?.let { a.put("pid", it) }
                val r = call("importFiles", a) as? JSONObject
                val pid = r?.optString("pid").orEmpty()
                if (pid.isNotEmpty()) selectedPid.value = pid
                messages.tryEmit(if (importPid != null) "Added ${r?.optInt("added")} file(s)" else "Imported ${r?.optInt("files")} files")
                nav.tryEmit(if (importPid != null) "workspace" else "builds")
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { messages.tryEmit(e.message ?: "Import failed") }
            finally { busy.update { it - "import" } }
        }
    }

    private fun displayName(u: Uri): String =
        act.contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: (u.lastPathSegment ?: "file")

    /** Stores the token from DefaultToken.kt (encrypted) once. A token saved or removed in the app is not overwritten. */
    private fun saveDefaultToken(bridge: CloudBridge) {
        val token = DefaultToken.GITHUB
        if (token.isEmpty()) return
        val prefs = act.getSharedPreferences("default_token", Context.MODE_PRIVATE)
        val mark = CloudCore.hex(java.security.MessageDigest.getInstance("SHA-256").digest(token.toByteArray()))
        if (prefs.getString("saved", "") == mark) return
        if (bridge.setToken("local", token) == "ok") prefs.edit().putString("saved", mark).apply()
    }

    companion object {
        private const val HOST = "zencloud.local"
        private val PAGES = setOf("engine.html", "cloudstudio-core.js", "cloudstudio-gen.js", "cloudstudio-import.js")
    }
}
