package com.zen.cloudstudio

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Zen AI Cloud Studio: network + crypto core.
 * Pure JVM on purpose (no android.* imports) so it is unit-tested on a normal JVM (tools/jvm-harness).
 * The WebView never sees the GitHub token: JavaScript only asks CloudBridge for "GET /repos/...", and this
 * object adds the Authorization header, enforces the host/path allowlist and redacts secrets from the answer.
 */
object CloudCore {
    /** Overridable so tests can point at a local fake GitHub server. Production value never changes. */
    @Volatile var apiBase: String = "https://api.github.com"
    /** Tests only: lets the allowlist accept http://127.0.0.1. */
    @Volatile var testHosts: Set<String> = emptySet()

    const val MAX_TEXT = 4 * 1024 * 1024          // largest API / log body returned to the page
    const val MAX_ZIP = 300L * 1024 * 1024        // largest artifact zip we download
    const val MAX_ENTRY = 250L * 1024 * 1024      // largest single file extracted from an artifact
    private const val CONNECT_MS = 15_000
    private const val READ_MS = 60_000

    class Resp(val status: Int, val body: String)
    class Saved(val name: String, val size: Long, val sha256: String, val file: File)

    // ---------------------------------------------------------------- allowlists
    private val hostSuffixes = listOf("api.github.com", "github.com", ".githubusercontent.com", ".blob.core.windows.net")

    fun hostAllowed(host: String?): Boolean {
        val h = (host ?: return false).lowercase()
        if (h in testHosts) return true
        return hostSuffixes.any { s -> if (s.startsWith(".")) h.endsWith(s) else h == s }
    }

    private val methods = setOf("GET", "POST", "PUT", "PATCH", "DELETE")
    private val blockedRepoSegments = setOf("keys", "hooks", "collaborators", "invitations", "transfer", "rulesets", "environments", "forks", "dispatches", "pages", "codespaces", "autolinks")
    private val blockedActionsSegments = setOf("secrets", "variables", "permissions", "runners", "oidc", "cache")

    /** Only a small set of GitHub REST calls are allowed. Everything else is refused before it leaves the phone. */
    fun pathAllowed(method: String, path: String): Boolean {
        val m = method.uppercase()
        if (m !in methods) return false
        if (path.isEmpty() || path.length > 2000) return false
        if (!path.startsWith("/")) return false
        if (path.contains("..") || path.contains("//") || path.contains('\r') || path.contains('\n') || path.contains('\\') || path.contains('@')) return false
        val p = path.substringBefore('?')
        if (p == "/user" || p == "/rate_limit") return m == "GET"
        if (!Regex("^/repos/[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}(/.*)?$").matches(p)) return false
        // the repository itself may not be deleted, only its contents
        if (m == "DELETE" && Regex("^/repos/[^/]+/[^/]+/?$").matches(p)) return false
        val seg = p.split('/')            // ["", "repos", owner, repo, seg4, seg5, ...]
        val s4 = seg.getOrNull(4)
        val s5 = seg.getOrNull(5)
        if (s4 != null && s4 in blockedRepoSegments) return false
        if (s4 == "actions" && s5 != null && s5 in blockedActionsSegments) return false
        if (s4 == "actions" && s5 == "workflows" && m != "GET") {           // only ".../workflows/<id>/dispatches" may be written
            return m == "POST" && seg.size == 8 && seg[7] == "dispatches"
        }
        if (s4 == "actions" && m == "DELETE") return s5 == "runs" || s5 == "artifacts"   // cleanup of old runs and artifacts
        return true
    }

    private fun urlAllowed(u: URL): Boolean {
        val https = u.protocol == "https"
        val testOk = u.protocol == "http" && u.host.lowercase() in testHosts
        return (https || testOk) && hostAllowed(u.host)
    }

    fun tokenShapeOk(t: String): Boolean = t.length in 20..255 && Regex("^(gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)$").matches(t)

    // ---------------------------------------------------------------- secret redaction
    private val secretPatterns = listOf(
        Regex("github_pat_[A-Za-z0-9_]{20,}"), Regex("gh[pousr]_[A-Za-z0-9]{20,}"), Regex("AIza[0-9A-Za-z_-]{30,}"),
        Regex("sk-[A-Za-z0-9_-]{20,}"), Regex("(?i)bearer\\s+[A-Za-z0-9._~+/=-]{16,}"),
        Regex("(?i)(password|passwd|secret|token|api[_-]?key|storePassword|keyPassword)(\\s*[:=]\\s*)[^\\s'\"]{4,}"),
        Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----[\\s\\S]*?-----END [A-Z ]*PRIVATE KEY-----")
    )

    fun redact(text: String, token: String? = null): String {
        var s = text
        if (!token.isNullOrEmpty()) s = s.replace(token, "***")
        for (r in secretPatterns) {
            s = if (r.pattern.startsWith("(?i)(password")) r.replace(s) { m -> m.groupValues[1] + m.groupValues[2] + "***" } else r.replace(s, "***")
        }
        return s
    }

    /** Keep the END of long text (build errors are at the end of a Gradle log). */
    fun tail(text: String, max: Int = MAX_TEXT): String =
        if (text.length <= max) text else "[... " + (text.length - max) + " earlier characters cut ...]\n" + text.substring(text.length - max)

    // ---------------------------------------------------------------- HTTP
    private fun open(url: URL, method: String, token: String?, body: String?): HttpURLConnection {
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = CONNECT_MS; c.readTimeout = READ_MS; c.instanceFollowRedirects = false
        c.requestMethod = method
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.setRequestProperty("User-Agent", "ZenAi-CloudStudio")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return c
    }

    private fun readBounded(c: HttpURLConnection, status: Int, cap: Int): String {
        val st = if (status >= 400) c.errorStream else c.inputStream
        if (st == null) return ""
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        st.use { while (true) { val n = it.read(buf); if (n < 0) break; out.write(buf, 0, n); if (out.size() > cap * 4) break } }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    /**
     * One GitHub REST call. Redirects (log and artifact downloads answer with 302) are followed by hand: the
     * Authorization header is dropped, and the target must itself be on the host allowlist and https.
     */
    fun request(method: String, path: String, body: String?, token: String?): Resp {
        val m = method.uppercase()
        if (!pathAllowed(m, path)) return Resp(400, "{\"message\":\"Zen AI blocked this request (not on the Cloud Studio allowlist)\"}")
        if (token.isNullOrEmpty()) return Resp(401, "{\"message\":\"No GitHub token saved. Open Cloud Settings and connect GitHub.\"}")
        var attempt = 0
        var last: IOException? = null
        while (attempt < 3) {
            attempt++
            try {
                var url = URL(apiBase + path)
                if (!urlAllowed(url)) return Resp(400, "{\"message\":\"Host not allowed\"}")
                var c = open(url, m, token, body)
                var st = c.responseCode
                var hops = 0
                while (st in intArrayOf(301, 302, 303, 307, 308) && hops < 3) {
                    val loc = c.getHeaderField("Location") ?: break
                    val next = URL(url, loc)
                    if (!urlAllowed(next)) { c.disconnect(); return Resp(400, "{\"message\":\"Redirect target not allowed\"}") }
                    c.disconnect()
                    url = next; hops++
                    c = open(url, "GET", null, null)          // pre-signed URL: no token
                    st = c.responseCode
                }
                if ((st == 502 || st == 503 || st == 504) && attempt < 3 && m == "GET") { c.disconnect(); Thread.sleep(600L * attempt); continue }
                val txt = readBounded(c, st, MAX_TEXT)
                c.disconnect()
                return Resp(st, tail(redact(txt, token)))
            } catch (e: IOException) {
                last = e
                if (m != "GET") break
                try { Thread.sleep(600L * attempt) } catch (_: InterruptedException) { }
            }
        }
        return Resp(0, "{\"message\":\"Network error: " + (last?.message ?: "unknown").replace("\"", "'") + "\"}")
    }

    // ---------------------------------------------------------------- artifact download: zip -> APK, with integrity data
    private fun safeBase(name: String): String = name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._-]"), "_").take(120).ifBlank { "file" }

    /**
     * Downloads /actions/artifacts/{id}/zip and extracts only the entries accepted by [keep] into outDir.
     * File names inside the zip are reduced to a safe base name (no zip-slip). Every kept file comes back with its SHA-256.
     */
    fun downloadArtifactFiles(owner: String, repo: String, artifactId: Long, token: String?, outDir: File, keep: (String) -> Boolean): List<Saved> {
        if (token.isNullOrEmpty()) return emptyList()
        if (!Regex("^[A-Za-z0-9_.-]{1,100}$").matches(owner) || !Regex("^[A-Za-z0-9_.-]{1,100}$").matches(repo)) return emptyList()
        val path = "/repos/$owner/$repo/actions/artifacts/$artifactId/zip"
        if (!pathAllowed("GET", path)) return emptyList()
        outDir.mkdirs()
        var url = URL(apiBase + path)
        var c = open(url, "GET", token, null)
        var st = c.responseCode
        var hops = 0
        while (st in intArrayOf(301, 302, 303, 307, 308) && hops < 3) {
            val loc = c.getHeaderField("Location") ?: break
            val next = URL(url, loc)
            if (!urlAllowed(next)) { c.disconnect(); throw IOException("Download address is not on the allowlist") }
            c.disconnect(); url = next; hops++
            c = open(url, "GET", null, null); st = c.responseCode
        }
        if (st != 200) { c.disconnect(); throw IOException("GitHub answered $st (the artifact may have expired or been deleted)") }
        val len = c.contentLengthLong
        if (len > MAX_ZIP) { c.disconnect(); throw IOException("Artifact is larger than the 300 MB limit") }
        val saved = ArrayList<Saved>()
        ZipInputStream(c.inputStream.buffered()).use { z ->
            var total = 0L
            while (saved.size < 40) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val base = safeBase(e.name)
                if (!keep(base)) continue
                val f = File(outDir, base)
                val md = MessageDigest.getInstance("SHA-256")
                var size = 0L
                FileOutputStream(f).use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = z.read(buf); if (n < 0) break
                        size += n; total += n
                        if (size > MAX_ENTRY || total > MAX_ZIP) { f.delete(); throw IOException("Artifact content is too large") }
                        o.write(buf, 0, n); md.update(buf, 0, n)
                    }
                }
                saved.add(Saved(base, size, hex(md.digest()), f))
            }
        }
        c.disconnect()
        return saved
    }

    /** First APK of an artifact (plus its .sha256 / build-info.json next to it). */
    fun downloadArtifact(owner: String, repo: String, artifactId: Long, token: String?, outDir: File): Saved? =
        downloadArtifactFiles(owner, repo, artifactId, token, outDir) { n -> n.endsWith(".apk") || n.endsWith(".sha256") || n == "build-info.json" }.firstOrNull { it.name.endsWith(".apk") }

    /** Screenshots, logcat and reports produced by the emulator test workflow. */
    fun downloadReports(owner: String, repo: String, artifactId: Long, token: String?, outDir: File): List<Saved> =
        downloadArtifactFiles(owner, repo, artifactId, token, outDir) { n -> n.endsWith(".png") || n.endsWith(".txt") || n.endsWith(".json") || n.endsWith(".log") }

    fun hex(b: ByteArray): String { val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x)); return sb.toString() }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val buf = ByteArray(64 * 1024); while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return hex(md.digest())
    }

    // ---------------------------------------------------------------- token at rest: AES-256-GCM
    /** The key comes from the Android Keystore (CloudBridge); tests pass an ordinary in-memory key. */
    class SecretBox(private val key: SecretKey) {
        fun seal(plain: String): String {
            // Android Keystore refuses a caller-chosen IV, so let the cipher create it and read it back.
            val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key)
            val iv = c.iv
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            return java.util.Base64.getEncoder().encodeToString(iv + ct)
        }
        fun open(sealed: String): String? = try {
            val raw = java.util.Base64.getDecoder().decode(sealed)
            val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }
}
