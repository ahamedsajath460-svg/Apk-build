package com.zen.cloudstudio

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.io.OutputStream

/**
 * The ONE place the app saves a user-facing file. Everything goes to the public Downloads folder (Downloads/Zen Cloud Studio[/sub]);
 * there is deliberately no fallback to app-private folders, so a file is never saved somewhere the user cannot find it.
 */
object DownloadsSaver {
    const val ROOT = "Zen Cloud Studio"
    /** Android 6-9 needs the storage permission to write into the public Downloads folder; Android 10+ does not. */
    fun needsPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 29 && ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    fun safeName(n: String): String = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "file" }

    /** Writes via [write] to Downloads/Zen Cloud Studio/[sub]/[name]. Returns the readable location. Throws IOException with a plain message. */
    fun save(ctx: Context, name: String, mime: String, sub: String = "", write: (OutputStream) -> Unit): String {
        val safe = safeName(name); val folder = if (sub.isBlank()) ROOT else "$ROOT/$sub"
        val type = mime.ifBlank { "application/octet-stream" }
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safe); put(MediaStore.MediaColumns.MIME_TYPE, type)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + folder)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Could not create the file in Downloads")
            ctx.contentResolver.openOutputStream(uri)?.use { write(it) } ?: throw IOException("Could not write to Downloads")
        } else {
            if (needsPermission(ctx)) throw IOException("Allow \"Files and media / Storage\" permission for Zen Cloud Studio so it can save into your Downloads folder.")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folder)
            if (!dir.isDirectory && !dir.mkdirs()) throw IOException("Could not create the Downloads/$folder folder")
            val f = File(dir, safe); f.outputStream().use { write(it) }
            try { MediaScannerConnection.scanFile(ctx.applicationContext, arrayOf(f.absolutePath), arrayOf(type), null) } catch (_: Throwable) { }
        }
        return "Downloads/$folder/$safe"
    }
}
