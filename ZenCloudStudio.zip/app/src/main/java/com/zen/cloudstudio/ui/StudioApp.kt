package com.zen.cloudstudio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zen.cloudstudio.Engine

val LocalEngine = staticCompositionLocalOf<Engine> { error("Engine not provided") }

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("home", "Home", Icons.Rounded.Home),
    Tab("create", "Create", Icons.Rounded.AutoAwesome),
    Tab("projects", "Projects", Icons.Rounded.FolderOpen),
    Tab("builds", "Builds", Icons.Rounded.Construction),
    Tab("more", "More", Icons.Rounded.GridView)
)

@Composable
fun StudioApp(engine: Engine, onExit: () -> Unit) {
    CompositionLocalProvider(LocalEngine provides engine) { Shell(engine, onExit) }
}

@Composable
private fun Shell(engine: Engine, onExit: () -> Unit) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val topLevel = Tabs.any { it.route == route }
    val snack = remember { SnackbarHostState() }
    val proposal by engine.proposal.collectAsState()

    fun tab(r: String) = nav.navigate(r) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true; restoreState = true
    }
    val back: () -> Unit = { nav.popBackStack() }

    LaunchedEffect(Unit) { engine.messages.collect { snack.showSnackbar(it) } }
    LaunchedEffect(Unit) {
        engine.nav.collect { r -> if (Tabs.any { it.route == r }) tab(r) else nav.navigate(r) }
    }
    BackHandler(enabled = route == "home") { onExit() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0),
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (topLevel) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route, onClick = { tab(t.route) },
                        icon = { Icon(t.icon, t.label) }, label = { Text(t.label) }
                    )
                }
            }
        }
    ) { inner ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(bottom = inner.calculateBottomPadding())) {
            composable("home") { HomeScreen(onCreate = { tab("create") }, onBuilds = { tab("builds") }, onSettings = { nav.navigate("settings") }) }
            composable("create") { CreateScreen(onSettings = { nav.navigate("settings") }, onOpenProject = { nav.navigate("workspace") }, onPaste = { nav.navigate("paste") }) }
            composable("projects") {
                ProjectsScreen(
                    onOpen = { engine.selectedPid.value = it.id; nav.navigate("workspace") },
                    onBuild = { engine.selectedPid.value = it.id; tab("builds") },
                    onNew = { tab("create") }
                )
            }
            composable("builds") { BuildsScreen(onSettings = { nav.navigate("settings") }) }
            composable("more") { MoreScreen { nav.navigate(it) } }
            composable("paste") { PasteScreen(back) }
            composable("workspace") { WorkspaceScreen(back) }
            composable("apks") { ApkScreen(back) }
            composable("sdk") { SdkScreen(back) }
            composable("settings") { SettingsScreen(back) }
            composable("preview") { PreviewScreen(back) }
            composable("device") { DeviceScreen(back) }
        }
    }

    proposal?.let { p ->
        AlertDialog(
            onDismissRequest = { },
            title = { Text("AI fix is ready") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.summary, style = MaterialTheme.typography.titleMedium)
                    p.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                    p.diff.take(3).forEach { d ->
                        Text(d.path, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(d.after.take(900), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                    if (p.diff.size > 3) Text("+ ${p.diff.size - 3} more file(s)", style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = { TextButton(onClick = { engine.answerProposal(true) }) { Text("Apply and rebuild") } },
            dismissButton = { TextButton(onClick = { engine.answerProposal(false) }) { Text("Reject", color = Bad) } }
        )
    }
}
