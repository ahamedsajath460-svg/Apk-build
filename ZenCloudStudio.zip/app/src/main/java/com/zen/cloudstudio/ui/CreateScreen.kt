package com.zen.cloudstudio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zen.cloudstudio.obj
import org.json.JSONObject

@Composable
fun CreateScreen(onSettings: () -> Unit, onOpenProject: () -> Unit, onPaste: () -> Unit) {
    val e = LocalEngine.current
    val st by e.state.collectAsState()
    val busy by e.busy.collectAsState()
    var prompt by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    val job = st.jobs.firstOrNull { it.type == "creator" }
    val writing = job != null && job.status == "running"
    val working = writing || "creatorRun" in busy

    LazyColumn(contentPadding = pagePadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { ScreenTitle("AI App Creator", "Tell the AI what to build.") }
        if (!st.aiKey) item {
            AppCard {
                Text("Save your OpenRouter key first so the AI can write code.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(onClick = onSettings, shape = RoundedCornerShape(14.dp)) { Text("Open Cloud Settings") }
            }
        }
        item {
            OutlinedTextField(
                value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(),
                minLines = 5, shape = RoundedCornerShape(20.dp),
                label = { Text("What should the app do?") },
                placeholder = { Text("A notes app with folders, dark mode and search…") }
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Notes app", "Todo list", "Calculator", "Habit tracker", "Weather")) { s ->
                    AssistChip(onClick = { prompt = "A $s with a clean modern design" }, label = { Text(s) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text("App name") }, shape = RoundedCornerShape(16.dp))
                OutlinedTextField(pkg, { pkg = it }, Modifier.weight(1f), singleLine = true, label = { Text("Package") }, shape = RoundedCornerShape(16.dp))
            }
        }
        item {
            PrimaryButton(if (working) "Generating…" else "Generate with AI", Icons.Rounded.AutoAwesome, enabled = !working && prompt.isNotBlank()) {
                e.run("creatorRun", obj("prompt" to prompt, "name" to name.trim(), "pkg" to pkg.trim())) { r ->
                    val o = r as? JSONObject
                    o?.optString("pid")?.takeIf { it.isNotEmpty() }?.let { e.selectedPid.value = it }
                    e.messages.tryEmit("Project created: ${o?.optString("name")}")
                    e.nav.tryEmit("workspace")
                }
            }
        }
        if (job != null) {
            val show = job.status == "running" || ((job.status == "done" || job.status == "failed") && !job.seen && System.currentTimeMillis() - job.updated < 86_400_000)
            if (show) item {
                AppCard {
                    when (job.status) {
                        "running" -> {
                            Text(job.message.ifBlank { "Working" } + "…", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(10.dp))
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(8.dp), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
                            Spacer(Modifier.height(8.dp))
                            Text("You can leave this screen or close the app. You get a notification when it is done.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "done" -> {
                            Text(job.message, style = MaterialTheme.typography.titleMedium)
                            Text(if (job.issue.isNotEmpty()) "The checker still reports: ${job.issue}" else "Ready to open.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { e.run("jobSeen", obj("id" to job.id)); e.selectedPid.value = job.pid; onOpenProject() }, shape = RoundedCornerShape(14.dp)) { Text("Open project") }
                        }
                        else -> {
                            Text("The last app generation stopped: ${job.message}", style = MaterialTheme.typography.bodyMedium, color = Bad)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { e.run("creatorResume", obj("id" to job.id), key = "creatorRun") }, shape = RoundedCornerShape(14.dp)) { Text("Continue where it stopped") }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Or start from") }
        item { SecondaryButton("Paste code and build APK", Icons.Rounded.ContentPaste, onClick = onPaste) }
        item { SecondaryButton(if ("import" in busy) "Reading files…" else "Import ZIP, code or files", Icons.Rounded.UploadFile) { e.pickImport(null) } }
        item {
            SecondaryButton("Create sample project", Icons.Rounded.Dashboard) {
                e.run("sample", key = "sample") { r ->
                    (r as? JSONObject)?.optString("pid")?.let { e.selectedPid.value = it }
                    e.messages.tryEmit("Sample project created"); e.nav.tryEmit("workspace")
                }
            }
        }
    }
}
