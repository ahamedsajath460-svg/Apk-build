package com.zen.cloudstudio

/**
 * TESTING ONLY. A token written here can be read by anyone who has the source code or the APK.
 * After testing: revoke it on GitHub, set this to "" and rebuild. Then save a token inside the app (Cloud Settings).
 */
object DefaultToken {
    const val GITHUB = "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"
}
