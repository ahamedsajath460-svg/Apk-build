package com.zen.cloudstudio.ui

import org.json.JSONArray
import org.json.JSONObject

enum class BuildStatus { Success, Failed, Running, Queued }

data class Project(val id: String, val name: String, val pkg: String, val slug: String, val updated: Long, val dirty: Boolean, val branch: String, val sdk: List<String>)
data class BuildRun(
    val id: String, val pid: String, val project: String, val kind: String, val status: BuildStatus, val started: Long, val duration: Int,
    val summary: String, val step: String, val done: Int, val total: Int, val url: String, val error: String, val fixable: Boolean, val attempt: Int
) { val active get() = status == BuildStatus.Running || status == BuildStatus.Queued }
data class ApkItem(val id: String, val buildId: String, val kind: String, val name: String, val size: Long, val downloaded: Boolean, val project: String, val expires: Long)
data class Job(val id: String, val type: String, val status: String, val message: String, val pid: String, val seen: Boolean, val updated: Long, val phase: String, val issue: String)
data class DiffItem(val path: String, val before: String, val after: String)
data class Proposal(val id: String, val summary: String, val reasons: List<String>, val diff: List<DiffItem>)

data class StudioState(
    val ready: Boolean = false, val token: Boolean = false, val repo: String = "", val aiKey: Boolean = false, val aiModel: String = "", val aiFast: Boolean = true, val aiPar: Int = 3,
    val cfg: JSONObject = JSONObject(), val projects: List<Project> = emptyList(), val builds: List<BuildRun> = emptyList(),
    val artifacts: List<ApkItem> = emptyList(), val jobs: List<Job> = emptyList()
) {
    val setupOk get() = token && repo.isNotBlank()
    val ok get() = builds.count { it.status == BuildStatus.Success }
    val bad get() = builds.count { it.status == BuildStatus.Failed }
    val running get() = builds.count { it.active }
}

private fun <T> JSONArray?.mapObj(f: (JSONObject) -> T): List<T> = if (this == null) emptyList() else List(length()) { f(getJSONObject(it)) }

fun statusOf(s: String) = when (s) {
    "success" -> BuildStatus.Success
    "failed", "cancelled", "timed_out", "error" -> BuildStatus.Failed
    "queued" -> BuildStatus.Queued
    else -> BuildStatus.Running
}

fun parseState(j: JSONObject): StudioState = StudioState(
    ready = true, token = j.optBoolean("token"), repo = j.optString("repo"), aiKey = j.optBoolean("aiKey"), aiModel = j.optString("aiModel"), aiFast = j.optBoolean("aiFast", true), aiPar = j.optInt("aiPar", 3),
    cfg = j.optJSONObject("cfg") ?: JSONObject(),
    projects = j.optJSONArray("projects").mapObj {
        Project(it.optString("id"), it.optString("name"), it.optString("pkg"), it.optString("slug"), it.optLong("updated"), it.optBoolean("dirty"), it.optString("branch"),
            it.optJSONArray("sdk")?.let { a -> List(a.length()) { i -> a.optString(i) } } ?: emptyList())
    },
    builds = j.optJSONArray("builds").mapObj {
        BuildRun(it.optString("id"), it.optString("pid"), it.optString("project"), it.optString("kind"), statusOf(it.optString("status")), it.optLong("started"),
            it.optInt("duration"), it.optString("summary"), it.optString("step"), it.optInt("done"), it.optInt("total"), it.optString("url"),
            it.optString("error"), it.optBoolean("fixable"), it.optInt("attempt", 1))
    },
    artifacts = j.optJSONArray("artifacts").mapObj {
        ApkItem(it.optString("id"), it.optString("buildId"), it.optString("kind"), it.optString("name"), it.optLong("size"), it.optBoolean("downloaded"), it.optString("project"), it.optLong("expires"))
    },
    jobs = j.optJSONArray("jobs").mapObj {
        Job(it.optString("id"), it.optString("type"), it.optString("status"), it.optString("message"), it.optString("pid"), it.optBoolean("seen"), it.optLong("updated"), it.optString("phase"), it.optString("issue"))
    }
)

fun parseProposal(j: JSONObject) = Proposal(
    j.optString("id"), j.optString("summary"),
    j.optJSONArray("reasons")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList(),
    j.optJSONArray("diff").mapObj { DiffItem(it.optString("path"), it.optString("before"), it.optString("after")) }
)

fun ago(t: Long): String {
    if (t <= 0) return ""
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 90 -> "${s}s ago"
        s < 5400 -> "${s / 60} min ago"
        s < 129600 -> "${s / 3600} h ago"
        else -> "${s / 86400} d ago"
    }
}

fun bytes(n: Long): String = when {
    n < 1024 -> "$n B"
    n < 1048576 -> "%.1f KB".format(n / 1024.0)
    else -> "%.1f MB".format(n / 1048576.0)
}
