package com.zen.cloudstudio

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream

/**
 * Isolated "Instant UI Preview". Generated HTML/CSS/JavaScript runs HERE, never in the main Zen AI WebView:
 *  - no JavaScript interfaces are added (no A2ZNative, no A2ZCloud, no access to chats, keys or the token)
 *  - all network loads are blocked (setBlockNetworkLoads + request interception + a Content-Security-Policy)
 *  - file / content access is off, links cannot navigate away.
 * This is a visual preview in a browser engine, NOT an Android emulator.
 */
class CloudPreviewActivity : Activity() {
    companion object {
        @Volatile var pendingHtml: String = ""
        @Volatile var pendingTitle: String = "Preview"
        @Volatile var pendingWidth: Int = 0
    }

    private lateinit var wv: WebView
    private var vw = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vw = pendingWidth
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(0xFF101014.toInt())
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL; bar.gravity = Gravity.CENTER_VERTICAL; bar.setPadding(12, 8, 12, 8)
        val title = TextView(this); title.text = "Preview (not an emulator): " + pendingTitle; title.setTextColor(0xFFE8E8F0.toInt()); title.textSize = 13f
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun chip(label: String, w: Int) { val b = Button(this); b.text = label; b.textSize = 11f; b.isAllCaps = false; b.minWidth = 0; b.minimumWidth = 0; b.setOnClickListener { vw = w; render() }; bar.addView(b) }
        chip("Phone", 0); chip("Tablet", 768); chip("Desktop", 1280)
        val close = Button(this); close.text = "Close"; close.textSize = 11f; close.isAllCaps = false; close.minWidth = 0; close.minimumWidth = 0; close.setOnClickListener { finish() }; bar.addView(close)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        wv = WebView(this)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.allowFileAccess = false; s.allowContentAccess = false; s.domStorageEnabled = false
        s.blockNetworkLoads = true
        s.setGeolocationEnabled(false)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.useWideViewPort = true; s.loadWithOverviewMode = true
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = true
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val sc = r.url.scheme?.lowercase()
                return if (sc == "data" || sc == "about" || sc == "blob") null else WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
        }
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        val csp = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; img-src data: blob:; media-src data: blob:; font-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'\">"
        val vp = "<meta name=\"viewport\" content=\"" + (if (vw > 0) "width=$vw" else "width=device-width, initial-scale=1") + "\">"
        var html = pendingHtml.replace(Regex("<meta[^>]*name=[\"']viewport[\"'][^>]*>", RegexOption.IGNORE_CASE), "")
        val m = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
        html = if (m != null) html.substring(0, m.range.last + 1) + csp + vp + html.substring(m.range.last + 1) else "<head>$csp$vp</head>$html"
        wv.loadDataWithBaseURL("about:blank", html, "text/html", "utf-8", null)
    }

    override fun onDestroy() { try { wv.destroy() } catch (_: Throwable) { }; pendingHtml = ""; super.onDestroy() }
}
