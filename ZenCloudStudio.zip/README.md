# Zen Cloud Studio

AI writes Android apps; GitHub Actions builds them.

## Setup
1. Create a PRIVATE GitHub repository. The token needs Contents, Actions and Workflows: read and write.
2. In the app: Cloud Settings > Repository (`owner/name`).
3. Tap "Set up GitHub and start build"; the app adds the build files itself.

AI keys, endpoints and models are in `app/src/main/assets/ai-config.js`.

## Token warning
`DefaultToken.kt` holds a test token. Anyone with this source or the APK can read it.
Before sharing: revoke the token, set the value to "", rebuild, and enter a token inside the app.

AI keys in `ai-config.js` are readable the same way: move them to a backend and revoke them before a public release.

## Release
The release build needs the signing secrets used by the repository's release workflow. Keep the same signing key for updates.
