package com.zen.cloudstudio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.zen.cloudstudio.ui.StudioApp
import com.zen.cloudstudio.ui.ZenTheme

/** Native Jetpack Compose UI. The Cloud Studio logic runs in a hidden engine, nothing web is shown. */
class MainActivity : AppCompatActivity() {
    private lateinit var engine: Engine

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        engine = Engine(this)
        setContent { ZenTheme { StudioApp(engine) { moveTaskToBack(true) } } }
        engine.start()
        askPermissions()
    }

    private fun askPermissions() {
        val wanted = ArrayList<String>()
        if (DownloadsSaver.needsPermission(this)) wanted.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (wanted.isNotEmpty()) ActivityCompat.requestPermissions(this, wanted.toTypedArray(), 1)
    }

    override fun onStart() { super.onStart(); AppState.visible = true }
    override fun onStop() { AppState.visible = false; super.onStop() }
    override fun onDestroy() { engine.stop(); super.onDestroy() }
}
